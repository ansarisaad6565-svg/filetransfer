FILE TRANSFER - by Saad
Modified build: Fast Mode receiver-address discovery fallback and larger transfer buffer.

BUILD:
1. Install Android Studio.
2. Unzip this package and open the FileTransfer folder in Android Studio.
3. Allow Gradle sync to finish (internet may be required to download dependencies).
4. Use Build > Build Bundle(s)/APK(s) > Build APK(s).
5. The debug APK is normally generated under app/build/outputs/apk/debug/.

IMPORTANT:
- These changes have not been compiled or tested on physical Android phones in this environment.
- Test Fast Mode in both directions on at least two Android devices, including the Android Wi-Fi connection prompt.
- Fast Mode uses Android LocalOnlyHotspot and WifiNetworkSpecifier; behavior and permissions can vary by device/OEM.
- Do not distribute the included debug signing key for a production release. Create your own private release key before publishing or selling a production build.
