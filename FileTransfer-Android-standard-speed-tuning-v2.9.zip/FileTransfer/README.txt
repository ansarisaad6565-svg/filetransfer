FILE TRANSFER (native Android) - by Saad

Version 2.9 source project. Includes a conservative transfer-throughput tuning pass: larger TCP socket buffers and 1 MiB receiver read buffers. This may improve sustained transfer performance on some Wi-Fi links, but cannot guarantee 60 MB/s; actual speed depends on both phones, Wi-Fi band/signal, and Android network behavior. Fast Mode connection logic has not been replaced with Wi-Fi Direct in this version.

1. Install Android Studio (free): developer.android.com/studio
2. Unzip this folder. Android Studio > Open > select the FileTransfer folder. Let Gradle sync finish (needs internet once).
3. Build > Build Bundle(s)/APK(s) > Build APK(s). Click "locate" to find app-debug.apk.
4. Send that APK to Android 10+ phones and install it. Updating over an older installation requires the same application ID and signing key.
