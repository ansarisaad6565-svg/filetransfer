FILE TRANSFER (native Android) - by Saad
1. Install Android Studio (free): developer.android.com/studio
2. Unzip this folder. Android Studio > Open > select the FileTransfer folder. Let Gradle sync finish (needs internet once).
3. Build > Build Bundle(s)/APK(s) > Build APK(s). Click "locate" to find app-debug.apk.
4. Send that APK to any Android 10+ phone and install it.
