package com.saad.filetransfer

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage

private class ScanFrame(c: Context) : View(c) {
    private val dim = Paint().apply { color = Color.argb(150, 0, 0, 0) }
    private val line = Paint().apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 8f; isAntiAlias = true }
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val s = minOf(w, h) * 0.72f
        val l = (w - s) / 2f; val t = h * 0.42f - s / 2f
        cv.drawRect(0f, 0f, w, t, dim); cv.drawRect(0f, t + s, w, h, dim)
        cv.drawRect(0f, t, l, t + s, dim); cv.drawRect(l + s, t, w, t + s, dim)
        cv.drawRoundRect(RectF(l, t, l + s, t + s), 36f, 36f, line)
    }
}

// Full-screen camera scanner. Returns the QR text in the result (extra "t").
class ScanActivity : ComponentActivity() {
    private lateinit var pv: PreviewView
    private var cam: Camera? = null
    private var done = false
    private var torch = false
    private val perm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) start() else finish() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = FrameLayout(this); root.setBackgroundColor(Color.BLACK)
        pv = PreviewView(this); root.addView(pv, FrameLayout.LayoutParams(-1, -1))
        root.addView(ScanFrame(this), FrameLayout.LayoutParams(-1, -1))
        val hint = TextView(this).apply {
            text = "Point the camera at the QR code on the other phone"
            setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER; setPadding(48, 110, 48, 0)
        }
        root.addView(hint, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        val torchBtn = Button(this).apply { text = "Flashlight"; setOnClickListener { torch = !torch; cam?.cameraControl?.enableTorch(torch) } }
        val cancelBtn = Button(this).apply { text = "Cancel"; setOnClickListener { finish() } }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 0, 0, 110); addView(torchBtn); addView(cancelBtn) }
        root.addView(row, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) start() else perm.launch(Manifest.permission.CAMERA)
    }

    private fun start() {
        val fut = ProcessCameraProvider.getInstance(this)
        fut.addListener({
            try {
                val p = fut.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
                val scanner = BarcodeScanning.getClient(BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build())
                val ana = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                ana.setAnalyzer(ContextCompat.getMainExecutor(this)) { proxy ->
                    val img = proxy.image
                    if (img == null || done) { proxy.close() } else {
                        scanner.process(InputImage.fromMediaImage(img, proxy.imageInfo.rotationDegrees))
                            .addOnSuccessListener { list ->
                                val v = list.firstOrNull { it.rawValue?.startsWith("FT") == true }?.rawValue
                                if (v != null && !done) { done = true; setResult(RESULT_OK, Intent().putExtra("t", v)); finish() }
                            }
                            .addOnCompleteListener { proxy.close() }
                    }
                }
                p.unbindAll()
                cam = p.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, ana)
            } catch (e: Exception) { finish() }
        }, ContextCompat.getMainExecutor(this))
    }
}
