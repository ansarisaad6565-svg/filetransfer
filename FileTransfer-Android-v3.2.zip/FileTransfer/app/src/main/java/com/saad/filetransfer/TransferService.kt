package com.saad.filetransfer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder

// Keeps the process alive (foreground service) so transfers continue when the app is minimized or the phone is locked.
class TransferService : Service() {
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("ft", "File transfer", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, build(this, "Ready to transfer", -1), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        return START_NOT_STICKY
    }
    override fun onTaskRemoved(rootIntent: Intent?) { stopSelf() }
    companion object {
        fun build(c: Context, text: String, pct: Int): Notification {
            val pi = PendingIntent.getActivity(c, 0,
                Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val b = Notification.Builder(c, "ft").setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("File Transfer").setContentText(text).setOngoing(true).setContentIntent(pi)
            if (pct >= 0) b.setProgress(100, pct, false)
            return b.build()
        }
        fun update(c: Context, text: String, pct: Int) {
            try { c.getSystemService(NotificationManager::class.java).notify(1, build(c, text, pct)) } catch (e: Exception) {}
        }
    }
}
