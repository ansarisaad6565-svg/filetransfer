FILE TRANSFER - by Saad
Modified build: Fast Mode receiver-address discovery fallback and larger transfer buffer.

BUILD:
1. Install Android Studio.
2. Unzip this package and open the FileTransfer folder in Android Studio.
3. Allow Gradle sync to finish (internet may be required to download dependencies).
4. Use Build > Build Bundle(s)/APK(s) > Build APK(s).
5. The debug APK is normally generated under app/build/outputs/apk/debug/.

IMPORTANT:
- These changes have not been compiled or tested on physical Android phones in this environment.
- Test Fast Mode in both directions on at least two Android devices, including the Android Wi-Fi connection prompt.
- Fast Mode uses Android LocalOnlyHotspot and WifiNetworkSpecifier; behavior and permissions can vary by device/OEM.
- Do not distribute the included debug signing key for a production release. Create your own private release key before publishing or selling a production build.


Fast Mode compatibility update
------------------------------
This update corrects a likely direct-Wi-Fi pairing failure: the app previously always configured
the Android Wi-Fi network request with a WPA passphrase. Open LocalOnlyHotspot configurations
must be requested without a passphrase. The join code now handles open, WPA2/transition, and
WPA3 hotspot security separately, validates QR connection details, waits longer for Android's
network approval, binds the app process to the selected Wi-Fi network, and reports clearer errors.
Fast Mode now checks the relevant runtime permission result before starting the hotspot.

Testing notes
-------------
Build and test on physical Android devices. Confirm both send/receive directions, approve the
Android Wi-Fi connection dialog, and test with the receiver's Fast Mode screen kept open.
Actual throughput depends on the phones' Wi-Fi hardware, Android implementation, signal, and
hotspot negotiation. This project has not been compiled or device-tested in this environment.
The current implementation uses Android LocalOnlyHotspot/WifiNetworkSpecifier; it is not a
full Wi-Fi Direct implementation identical to ShareMe.
