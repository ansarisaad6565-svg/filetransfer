package com.saad.filetransfer

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread

/**
 * Tiny web server for iPhone / iPad. iOS cannot run the Android app or Wi-Fi Direct, so the iPhone just opens a link
 * (QR code) in Safari: it downloads the files offered by this phone, or uploads files to this phone.
 * Completely separate from the normal phone-to-phone transfer.
 */
class IosShare(
    val token: String,
    private val send: Boolean,                                        // true: iPhone downloads from us. false: iPhone uploads to us
    private val files: () -> List<Item>,                              // files offered to the iPhone (send mode)
    private val openIn: (Item) -> InputStream,                        // open one offered file
    private val newFile: (String) -> Pair<Uri, OutputStream>,         // receive mode: create the target file (pending)
    private val finishFile: (Uri) -> Unit,                            // mark a received file complete
    private val dropFile: (Uri) -> Unit,                              // delete a partial file
    private val isPaused: () -> Boolean,
    private val emitEvt: (JSONObject) -> Unit,                        // events to the app UI
    private val notify: (String, Int) -> Unit                         // notification text + percent
) {
    private var srv: ServerSocket? = null
    val port: Int get() = srv?.localPort ?: 0
    private val socks = CopyOnWriteArrayList<Socket>()
    @Volatile private var abort = 0                                   // bumped by cancelAll(): running transfers stop
    private val linked = AtomicBoolean(false)
    private val doneFired = AtomicBoolean(false)
    private val completed = java.util.Collections.synchronizedSet(HashSet<Int>())
    private val sentAll = AtomicLong(0)
    @Volatile private var t0 = 0L
    @Volatile private var last = 0L
    @Volatile private var spT = 0L
    @Volatile private var spD = 0L
    @Volatile private var spE = 0.0

    fun start(): Int {
        val s = ServerSocket(0, 30); srv = s
        thread(isDaemon = true) {
            while (!s.isClosed) {
                val c = try { s.accept() } catch (e: Exception) { break }
                socks.add(c)
                thread { try { handle(c) } catch (e: Exception) {} finally { try { c.close() } catch (e: Exception) {}; socks.remove(c) } }
            }
        }
        return s.localPort
    }
    fun stop() {
        abort++
        try { srv?.close() } catch (e: Exception) {}
        socks.forEach { try { it.close() } catch (e: Exception) {} }; socks.clear()
    }
    fun cancelAll() {   // stop what is running now, the link stays usable
        abort++
        socks.forEach { try { it.close() } catch (e: Exception) {} }
    }

    // ---------- HTTP ----------
    private fun readHead(ins: InputStream): String? {
        val sb = StringBuilder(); var m = 0
        while (sb.length < 16384) {
            val b = ins.read(); if (b < 0) return null
            sb.append(b.toChar())
            val exp = if (m % 2 == 0) 13 else 10
            m = if (b == exp) m + 1 else if (b == 13) 1 else 0
            if (m == 4) return sb.toString()
        }
        return null
    }
    private fun respond(o: OutputStream, code: String, type: String, body: ByteArray) {
        o.write(("HTTP/1.1 $code\r\nContent-Type: $type; charset=utf-8\r\nContent-Length: ${body.size}\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n").toByteArray())
        o.write(body); o.flush()
    }
    private fun handle(c: Socket) {
        c.tcpNoDelay = true; c.soTimeout = 30000
        val ins = BufferedInputStream(c.getInputStream(), 65536)
        val head = readHead(ins) ?: return
        val lines = head.split("\r\n")
        val req = lines[0].split(" ")
        if (req.size < 2) return
        val method = req[0]; val target = req[1]
        val path = target.substringBefore('?')
        val q = target.substringAfter('?', "").split('&').filter { it.isNotEmpty() }.associate {
            URLDecoder.decode(it.substringBefore('='), "UTF-8") to URLDecoder.decode(it.substringAfter('=', ""), "UTF-8")
        }
        val hdrs = HashMap<String, String>()
        for (i in 1 until lines.size) { val k = lines[i].indexOf(':'); if (k > 0) hdrs[lines[i].substring(0, k).trim().lowercase()] = lines[i].substring(k + 1).trim() }
        val o = c.getOutputStream()
        if (q["t"] != token) { respond(o, "403 Forbidden", "text/plain", "This link is wrong or old. Scan the QR code on the Android phone again.".toByteArray()); return }
        when {
            method == "GET" && (path == "/" || path == "/index.html") -> page(o)
            method == "GET" && send && path.startsWith("/dl/") -> download(o, path.removePrefix("/dl/").toIntOrNull() ?: -1)
            method == "POST" && !send && path == "/up" -> upload(ins, o, q["name"] ?: "file", hdrs)
            else -> respond(o, "404 Not Found", "text/plain", "Not found".toByteArray())
        }
    }

    // ---------- pages ----------
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    private fun fmt(n: Long): String = if (n >= 1073741824L) String.format(java.util.Locale.US, "%.2f GB", n / 1073741824.0)
        else if (n >= 1048576L) String.format(java.util.Locale.US, "%.1f MB", n / 1048576.0) else String.format(java.util.Locale.US, "%d KB", n / 1024)
    private fun shell(title: String, body: String) = """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>File Transfer</title><style>
:root{color-scheme:light dark}body{font-family:-apple-system,system-ui,sans-serif;margin:0;padding:18px;background:#f5f6fa;color:#161824}
@media(prefers-color-scheme:dark){body{background:#0e0f14;color:#eceef4}.r{background:#181a22}}
h1{font-size:22px;margin:4px 0 6px}p{color:#888;margin:6px 0 14px;font-size:15px}
.r{display:flex;align-items:center;justify-content:space-between;gap:10px;background:#fff;border-radius:16px;padding:14px;margin:10px 0;word-break:break-all}
.n{font-weight:600;font-size:15px}small{color:#888;font-weight:400}
.b{display:inline-block;background:linear-gradient(135deg,#7c3aed,#ec4899);color:#fff;border:0;border-radius:14px;padding:12px 18px;font-size:16px;font-weight:700;text-decoration:none;white-space:nowrap}
input[type=file]{width:100%;margin:10px 0 14px;font-size:16px}
</style></head><body><h1>$title</h1>$body</body></html>"""
    private fun page(o: OutputStream) {
        val html: String
        if (send) {
            sentAll.set(0); t0 = 0; spT = 0; spD = 0; spE = 0.0; completed.clear(); doneFired.set(false)
            val list = files()
            val rows = list.mapIndexed { i, f ->
                "<div class=r><div class=n>${esc(f.name)}<br><small>${fmt(f.size)}</small></div><a class=b href=\"/dl/$i?t=$token\">Download</a></div>"
            }.joinToString("")
            html = shell("Files from Android", "<p>Tap <b>Download</b> for each file, then confirm in Safari. Files are saved in the Files app under Downloads.</p>" +
                (if (list.isEmpty()) "<p>No files are shared right now.</p>" else rows))
        } else {
            html = shell("Send to Android", """<p>Choose photos, videos or files on this iPhone, then tap Send. Keep this page open until it says done.</p>
<input id="f" type="file" multiple><button class="b" onclick="up()">Send to Android</button><div id="l"></div>
<script>
function up(){var fs=document.getElementById('f').files;if(!fs.length){alert('Choose files first');return}
var l=document.getElementById('l'),i=0;
(function next(){if(i>=fs.length){l.insertAdjacentHTML('beforeend','<p><b>All done &#10003;</b></p>');return}
var f=fs[i++],row=document.createElement('div');row.className='r';row.textContent=f.name+'  0%';l.appendChild(row);
var x=new XMLHttpRequest();x.open('POST','/up?t=$token&name='+encodeURIComponent(f.name));
x.upload.onprogress=function(e){if(e.lengthComputable)row.textContent=f.name+'  '+Math.round(e.loaded*100/e.total)+'%'};
x.onload=function(){row.textContent=f.name+(x.status==200?'  \u2713':'  failed ('+x.status+')');next()};
x.onerror=function(){row.textContent=f.name+'  failed';next()};
x.send(f)})()}
</script>""")
        }
        respond(o, "200 OK", "text/html", html.toByteArray())
    }

    // ---------- progress ----------
    private fun announce() {
        if (linked.compareAndSet(false, true)) emitEvt(JSONObject().put("t", "linked").put("route", "iPhone browser (Wi-Fi)"))
    }
    private fun smooth(done: Long, now: Long, start: Long): Double {
        if (spT == 0L || now - spT > 3000 || done < spD) {
            spT = now; spD = done
            if (spE == 0.0) spE = done / 1048576.0 / maxOf(0.1, (now - start) / 1000.0)
            return spE
        }
        val dt = now - spT
        if (dt >= 400) {
            val inst = (done - spD) / 1048576.0 / (dt / 1000.0)
            spE = if (spE == 0.0) inst else spE * 0.6 + inst * 0.4
            spT = now; spD = done
        }
        return spE
    }
    private fun progress(t: String, name: String, i: Int, n: Int, done: Long, total: Long, start: Long, force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!force && now - last < 250) return
        last = now
        val sp = smooth(done, now, start)
        emitEvt(JSONObject().put("t", t).put("name", name).put("i", i).put("n", n).put("done", done).put("total", total)
            .put("speed", sp).put("paused", isPaused()).put("eta", if (sp > 0) maxOf(0L, total - done) / 1048576.0 / sp else 0.0))
        notify((if (t == "s") "Sending " else "Receiving ") + name + " - " + String.format(java.util.Locale.US, "%.1f", sp) + " MB/s",
            if (total > 0) (done * 100 / total).toInt() else 0)
    }

    // ---------- iPhone downloads a file from us ----------
    private fun download(o: OutputStream, idx: Int) {
        val list = files()
        val item = list.getOrNull(idx)
        if (item == null) { respond(o, "404 Not Found", "text/plain", "File not found".toByteArray()); return }
        val my = abort
        val total = list.sumOf { it.size }
        val ascii = item.name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val enc = URLEncoder.encode(item.name, "UTF-8").replace("+", "%20")
        o.write(("HTTP/1.1 200 OK\r\nContent-Type: application/octet-stream\r\nContent-Length: ${item.size}\r\n" +
            "Content-Disposition: attachment; filename=\"$ascii\"; filename*=UTF-8''$enc\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n").toByteArray())
        announce()
        val buf = ByteArray(1 shl 20); var n = 0L
        openIn(item).use { ins ->
            while (abort == my) {
                while (isPaused() && abort == my) Thread.sleep(150)
                if (abort != my) break
                val k = ins.read(buf); if (k < 0) break
                o.write(buf, 0, k); n += k
                val d = sentAll.addAndGet(k.toLong()); if (t0 == 0L) t0 = System.currentTimeMillis()
                progress("s", item.name, idx + 1, list.size, minOf(d, total), total, t0)
            }
        }
        o.flush()
        if (abort == my && n >= item.size) {
            completed.add(idx)
            if (completed.size >= list.size && doneFired.compareAndSet(false, true)) {
                val secs = maxOf(0.1, (System.currentTimeMillis() - t0) / 1000.0)
                emitEvt(JSONObject().put("t", "sdone").put("size", total).put("avg", total / 1048576.0 / secs)
                    .put("names", JSONArray().also { a -> list.forEach { x -> a.put(x.name) } }))
            }
        }
    }

    // ---------- iPhone uploads a file to us ----------
    private fun upload(ins: InputStream, o: OutputStream, rawName: String, h: Map<String, String>) {
        val my = abort
        val name = rawName.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").trim().ifBlank { "file" }
        val len = h["content-length"]?.toLongOrNull() ?: -1L
        val (uri, out) = newFile(name)
        announce()
        var got = 0L; var ok = false
        val start = System.currentTimeMillis(); spT = 0; spD = 0; spE = 0.0
        try {
            out.use { w ->
                val buf = ByteArray(1 shl 20)
                while (abort == my && (len < 0 || got < len)) {
                    while (isPaused() && abort == my) Thread.sleep(150)
                    if (abort != my) break
                    val want = if (len < 0) buf.size else minOf(buf.size.toLong(), len - got).toInt()
                    val k = ins.read(buf, 0, want); if (k < 0) break
                    w.write(buf, 0, k); got += k
                    progress("p", name, 1, 1, got, if (len > 0) len else got, start)
                }
            }
            ok = abort == my && (len < 0 || got >= len)
        } catch (e: Exception) { ok = false }
        if (ok) {
            finishFile(uri)
            val secs = maxOf(0.1, (System.currentTimeMillis() - start) / 1000.0)
            emitEvt(JSONObject().put("t", "pdone").put("size", got).put("avg", got / 1048576.0 / secs)
                .put("names", JSONArray().put(name)).put("uris", JSONArray().put(uri.toString())))
            try { respond(o, "200 OK", "text/plain", "OK".toByteArray()) } catch (e: Exception) {}
        } else {
            dropFile(uri)
            try { respond(o, "500 Internal Server Error", "text/plain", "Failed".toByteArray()) } catch (e: Exception) {}
        }
    }
}
