package com.saad.filetransfer

import android.content.ContentValues
import android.content.Intent
import android.content.Context
import android.Manifest
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataInputStream
import java.io.File
import java.io.BufferedOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread

class Cancelled : java.io.IOException("cancelled")

data class Item(val uri: Uri?, val name: String, val size: Long, val path: String? = null)

class MainActivity : ComponentActivity() {
    companion object {
        @Volatile var cur: WebView? = null
        @Volatile var snap: String = ""
        @Volatile var paused = false
        @Volatile var cancelled = false
        @Volatile var peerHost = ""
        @Volatile var peerPort = 0
        @Volatile var peerTok = ""
        val socks = java.util.concurrent.CopyOnWriteArrayList<Socket>()
    }
    private var wake: android.os.PowerManager.WakeLock? = null
    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private var lastAsked = ""
    private val oneLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        // denied for good ("don't ask again"): send the user to the app's permission page
        if (!granted && lastAsked.isNotEmpty() && !shouldShowRequestPermissionRationale(lastAsked))
            try { startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (e: Exception) {}
        emit(JSONObject().put("t", "perm"))
    }
    private lateinit var wv: WebView
    private val items = java.util.concurrent.CopyOnWriteArrayList<Item>()
    private var srv: ServerSocket? = null
    private var tok = ""
    private val sent = AtomicLong(0)
    @Volatile private var t0 = 0L
    @Volatile private var last = 0L
    private var lock: WifiManager.WifiLock? = null
    private val BUF = 1 shl 20
    private val fin = AtomicBoolean(false)

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { us ->
        us.forEach { u ->
            contentResolver.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) items.add(Item(u,
                    c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)),
                    c.getLong(c.getColumnIndexOrThrow(OpenableColumns.SIZE))))
            }
        }
        emitFiles()
    }

    private val scanner = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val txt = if (r.resultCode == RESULT_OK) r.data?.getStringExtra("t") else null
        if (txt != null) {
            pullMode = false
            if (txt.startsWith("WIFI:")) {   // a normal phone-hotspot "Share QR code": join it from inside the app
                val w = wifiQr(txt)
                val t = (w["T"] ?: "WPA").uppercase()
                withJoinPerms { joinHotspotOnly(w["S"] ?: "", w["P"] ?: "", if (t.contains("SAE") || t == "WPA3") 3 else if (t == "NOPASS" || t.isEmpty()) 0 else 1) }
                return@registerForActivityResult
            }
            val p = txt.split("|")
            if (p.size == 4 && p[0] == "FT1") download(p[1], p[2].toIntOrNull() ?: 0, p[3])
            else if (p.size == 4 && p[0] == "FT2") link(p[1], p[2].toIntOrNull() ?: 0, p[3])
            else if (p.size >= 7 && p[0] == "FT4") {
                val ssid4 = String(android.util.Base64.decode(p[4], android.util.Base64.URL_SAFE))
                val pass4 = String(android.util.Base64.decode(p[5], android.util.Base64.URL_SAFE))
                withJoinPerms { joinAndLink(p[1], p[2].toIntOrNull() ?: 0, p[3], ssid4, pass4, p[6].toIntOrNull() ?: 1, p.getOrElse(7) { "" }) }
            }
            else if (p.size >= 7 && p[0] == "FT5") {
                val ssid5 = String(android.util.Base64.decode(p[4], android.util.Base64.URL_SAFE))
                val pass5 = String(android.util.Base64.decode(p[5], android.util.Base64.URL_SAFE))
                withJoinPerms { pullMode = true; stopHotspot(); joinAndLink(p[1], p[2].toIntOrNull() ?: 0, p[3], ssid5, pass5, p[6].toIntOrNull() ?: 1, p.getOrElse(7) { "" }) }
            }
            else if (p.size == 6 && p[0] == "FT3") joinAndLink(p[1], p[2].toIntOrNull() ?: 0, p[3], p[4], p[5])
            else err("That is not a File Transfer QR code.")
        }
    }

    // FIX: the phone that JOINS the direct Wi-Fi (sender) also needs Location / Nearby-devices permission,
    // otherwise Android's Wi-Fi scan finds nothing and shows "device not found".
    private var afterPerm: (() -> Unit)? = null
    private val joinPermLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val go = afterPerm; afterPerm = null; go?.invoke()
    }
    private fun askAll() {
        val need = (fastPerms().toList() + Manifest.permission.CAMERA).filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) joinPermLauncher.launch(need.toTypedArray())
    }
    private fun withJoinPerms(go: () -> Unit) {
        val need = fastPerms().any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need) { afterPerm = go; joinPermLauncher.launch(fastPerms()) } else go()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        wv = WebView(this)
        cur = wv
        setContentView(wv)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.loadUrl("file:///android_asset/index.html")
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (snap.isNotEmpty()) moveTaskToBack(true) else wv.evaluateJavascript("goBack()") { if (it != "true") finish() } }
        })
    }

    override fun onDestroy() { if (cur === wv) cur = null; super.onDestroy() }
    private fun emit(o: JSONObject) {
        val t = o.optString("t")
        if (t == "s" || t == "p") snap = o.toString()
        else if (t == "sdone" || t == "pdone" || t == "err" || t == "cancelled") {
            snap = ""
            TransferService.update(applicationContext, if (t == "sdone" || t == "pdone") "Transfer complete" else "Transfer stopped", -1)
        }
        val w = cur ?: return
        w.post { w.evaluateJavascript("onNative($o)", null) }
    }
    private fun closeAll(keep: Socket? = null) {
        socks.forEach { if (it !== keep) try { it.close() } catch (e: Exception) {} }
        socks.removeAll { it.isClosed }
    }
    private fun svc(on: Boolean) {
        try {
            if (on) {
                startForegroundService(Intent(this, TransferService::class.java))
                if (wake == null) wake = (getSystemService(Context.POWER_SERVICE) as android.os.PowerManager)
                    .newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "ft:xfer").apply { setReferenceCounted(false) }
                wake?.acquire(4 * 3600 * 1000L)
            } else {
                stopService(Intent(this, TransferService::class.java))
                if (wake?.isHeld == true) wake?.release()
            }
        } catch (e: Exception) {}
    }
    private fun err(m: String) = emit(JSONObject().put("t", "err").put("msg", m))
    private fun emitFiles() {
        val a = JSONArray(); items.forEach { a.put(JSONObject().put("n", it.name).put("s", it.size)) }
        emit(JSONObject().put("t", "files").put("list", a))
    }
    private fun wifi(on: Boolean) {
        if (on) {
            if (lock == null) lock = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
                .createWifiLock(if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY else WifiManager.WIFI_MODE_FULL_HIGH_PERF, "ft").apply { setReferenceCounted(false) }
            lock?.acquire()
        } else if (lock?.isHeld == true) lock?.release()
    }
    private fun prog(t: String, name: String, i: Int, n: Int, done: Long, total: Long, start: Long) {
        val now = System.currentTimeMillis()
        if (now - last < 200 && done < total) return
        last = now
        val sp = done / 1048576.0 / maxOf(0.1, (now - start) / 1000.0)
        emit(JSONObject().put("t", t).put("name", name).put("i", i).put("n", n).put("done", done)
            .put("total", total).put("speed", sp).put("paused", paused).put("eta", if (sp > 0) (total - done) / 1048576.0 / sp else 0.0))
        TransferService.update(applicationContext, (if (t == "s") "Sending " else "Receiving ") + name + " - " + String.format("%.1f", sp) + " MB/s" + (if (paused) " (paused)" else ""),
            if (total > 0) (done * 100 / total).toInt() else 0)
    }
    @Suppress("DEPRECATION")
    private fun route(peer: String, forced: Boolean = false): String = try {
        if (p2pMgr != null && p2pLabel.isNotEmpty()) return p2pLabel
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val g = wm.dhcpInfo.gateway
        val gw = "${g and 255}.${(g shr 8) and 255}.${(g shr 16) and 255}.${(g shr 24) and 255}"
        var weHost = hotspot != null
        for (n in NetworkInterface.getNetworkInterfaces()) { val nm = n.name.lowercase()
            if ((nm.startsWith("ap") || nm.startsWith("swlan") || nm.startsWith("softap") || nm.startsWith("p2p")) && n.inetAddresses.toList().any { it is Inet4Address }) weHost = true }
        val wi = wm.connectionInfo; val f = wi.frequency
        val band = if (f >= 5900) "6 GHz" else if (f >= 4900) "5 GHz" else if (f > 0) "2.4 GHz" else ""
        val info = if (band.isNotEmpty() && gw == peer) " [$band, ${wi.linkSpeed} Mbps]" else ""
        if (forced || weHost) "Direct Wi-Fi" + info
        else if (gw == peer) "Direct Wi-Fi (hotspot)" + info
        else "Wi-Fi network (via router)" + (if (band.isNotEmpty()) " [$band, ${wi.linkSpeed} Mbps]" else "")
    } catch (e: Exception) { if (forced) "Direct Wi-Fi" else "Wi-Fi network" }
    // parse "WIFI:T:WPA;S:name;P:password;;" (the QR that Android/MIUI hotspot screens show)
    private fun wifiQr(t: String): Map<String, String> {
        val out = HashMap<String, String>(); val fields = ArrayList<String>(); val cur = StringBuilder(); var esc = false
        for (ch in t.substring(5)) {
            if (esc) { cur.append(ch); esc = false }
            else if (ch == '\\') esc = true
            else if (ch == ';') { fields.add(cur.toString()); cur.setLength(0) }
            else cur.append(ch)
        }
        if (cur.isNotEmpty()) fields.add(cur.toString())
        for (f in fields) { val i = f.indexOf(':'); if (i > 0) out[f.substring(0, i)] = f.substring(i + 1) }
        return out
    }
    @Suppress("DEPRECATION")
    private fun joinHotspotOnly(ssid: String, pass: String, sec: Int) {
        if (ssid.isEmpty()) { err("That Wi-Fi QR code has no network name."); return }
        thread {
            try {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                fun next() { status("Connected to \"" + ssid + "\". Now scan the QR code shown in the other phone's File Transfer app."); runOnUiThread { scanner.launch(Intent(this@MainActivity, ScanActivity::class.java)) } }
                if (wm.isWifiEnabled && (wm.connectionInfo?.ssid ?: "") == "\"" + ssid + "\"") { next(); return@thread }
                status("Joining \"" + ssid + "\"... tap Connect if Android asks")
                val sb = WifiNetworkSpecifier.Builder().setSsid(ssid)
                if (sec == 3) sb.setWpa3Passphrase(pass) else if (sec == 1) sb.setWpa2Passphrase(pass)
                val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                    .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).setNetworkSpecifier(sb.build()).build()
                netCb?.let { try { cm.unregisterNetworkCallback(it) } catch (e: Exception) {} }
                val cb = object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) { cm.bindProcessToNetwork(network); direct = false; next() }
                    override fun onUnavailable() { err("Could not join \"" + ssid + "\". Check the hotspot is ON and try again.") }
                }
                netCb = cb
                cm.requestNetwork(req, cb, 45000)
            } catch (e: Exception) { err("Could not join the hotspot: " + e.javaClass.simpleName + " " + (e.message ?: "")) }
        }
    }
    private fun ip(): String {
        var best = ""
        for (n in NetworkInterface.getNetworkInterfaces()) for (a in n.inetAddresses)
            if (a is Inet4Address && !a.isLoopbackAddress && a.isSiteLocalAddress &&
                (best.isEmpty() || n.name.startsWith("wlan") || n.name.startsWith("ap"))) best = a.hostAddress ?: ""
        return best
    }

    // ---------- sender: raw-TCP HTTP server, 1 MB buffers ----------
    private fun serve() = thread(isDaemon = true) {
        val s = srv ?: return@thread
        while (!s.isClosed) {
            val c = try { s.accept() } catch (e: Exception) { break }
            socks.add(c); thread { try { handle(c) } catch (e: Exception) {} finally { try { c.close() } catch (e: Exception) {}; socks.remove(c) } }
        }
    }
    private fun handle(c: Socket) {
        c.sendBufferSize = 2 shl 20; c.tcpNoDelay = true
        val r = c.getInputStream().bufferedReader()
        val line = r.readLine() ?: return
        while (!r.readLine().isNullOrEmpty()) { }
        val p = line.split(" ").getOrNull(1) ?: return
        val o = c.getOutputStream()
        fun hdr(code: String, len: Long) = o.write("HTTP/1.1 $code\r\nContent-Length: $len\r\nConnection: close\r\n\r\n".toByteArray())
        val q = p.substringAfter('?', "").split('&').associate { it.substringBefore('=') to it.substringAfter('=', "") }
        if (q["t"] != tok) { hdr("403 Forbidden", 0); return }
        if (p.startsWith("/bye")) { cancelled = true; paused = false; hdr("200 OK", 0); o.flush(); emit(JSONObject().put("t", "cancelled").put("by", "peer")); closeAll(c); return }
        if (cancelled && !p.startsWith("/hello")) { hdr("410 Gone", 0); return }
        if (p.startsWith("/hello")) {   // receiver side: the sender scanned our QR and tells us where its files are
            hdr("200 OK", 0); o.flush()
            val sp = q["port"]?.toIntOrNull(); val st = q["st"]
            if (sp != null && st != null) { cancelled = false; paused = false; emit(JSONObject().put("t", "linked").put("route", route(c.inetAddress.hostAddress ?: ""))); download(c.inetAddress.hostAddress ?: "", sp, st) }
            return
        }
        if (p.startsWith("/list")) {
            if (hotspot != null) emit(JSONObject().put("t", "linked").put("route", route(c.inetAddress.hostAddress ?: "", true)))
            val a = JSONArray(); items.forEach { a.put(JSONObject().put("n", it.name).put("s", it.size)) }
            val b = a.toString().toByteArray(); sent.set(0); t0 = 0; fin.set(false)
            hdr("200 OK", b.size.toLong()); o.write(b)
        } else if (p.startsWith("/f/")) {
            val idx = p.substring(3).substringBefore("?").toInt()
            val item = items.getOrNull(idx) ?: return
            val off = q["o"]?.toLongOrNull() ?: 0L
            val len = q["n"]?.toLongOrNull() ?: (item.size - off)
            val total = items.sumOf { x -> x.size }
            hdr("200 OK", len)
            (if (item.path != null) FileInputStream(item.path) else contentResolver.openInputStream(item.uri!!)!!).use { ins ->
                var skipped = 0L
                while (skipped < off) { val sk = ins.skip(off - skipped); if (sk <= 0) break; skipped += sk }
                val buf = ByteArray(BUF)
                var rem = len
                while (rem > 0) {
                    while (paused && !cancelled) Thread.sleep(150); if (cancelled) break
                    val k = ins.read(buf, 0, minOf(rem, BUF.toLong()).toInt()); if (k < 0) break
                    o.write(buf, 0, k); rem -= k
                    val d = sent.addAndGet(k.toLong()); if (t0 == 0L) t0 = System.currentTimeMillis()
                    prog("s", item.name, idx + 1, items.size, d, total, t0)
                }
            }
            o.flush()
            if (sent.get() >= total && fin.compareAndSet(false, true)) emit(JSONObject().put("t", "sdone").put("size", total)
                .put("names", JSONArray().also { a -> items.forEach { x -> a.put(x.name) } }))
        }
        o.flush()
    }

    // ---------- receiver: streams straight into MediaStore (Gallery) ----------
    private fun entry(name: String, mime: String): Uri {
        val (col, dir) = when {
            mime.startsWith("image/") -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_PICTURES
            mime.startsWith("video/") -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MOVIES
            mime.startsWith("audio/") -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MUSIC
            else -> MediaStore.Downloads.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_DOWNLOADS
        }
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name); put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "$dir/FileTransfer"); put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        return contentResolver.insert(col, v)!!
    }
    // raw socket: 2 MB receive window, no HTTP library overhead
    private fun open(host: String, port: Int, path: String): Socket {
        if (cancelled) throw Cancelled()
        socks.removeAll { it.isClosed }
        val s = Socket(); s.receiveBufferSize = 2 shl 20; s.tcpNoDelay = true; s.keepAlive = true; s.soTimeout = 20000
        socks.add(s)
        try {
            s.connect(InetSocketAddress(host, port), 6000)
            s.getOutputStream().write("GET $path HTTP/1.1\r\nHost: $host\r\nConnection: close\r\n\r\n".toByteArray())
            val i = s.getInputStream(); var m = 0; val hb = StringBuilder()
            while (m < 4) {
                val b = i.read(); if (b < 0) throw java.io.IOException("closed")
                if (hb.length < 40) hb.append(b.toChar())
                val exp = if (m % 2 == 0) 13 else 10
                m = if (b == exp) m + 1 else if (b == 13) 1 else 0
            }
            val code = hb.toString().substringAfter(' ').take(3)
            if (code == "410") throw Cancelled()
            if (code != "200") throw java.io.IOException("HTTP $code")
        } catch (e: Exception) { socks.remove(s); try { s.close() } catch (x: Exception) {}; throw e }
        return s
    }
    // sender side: scanned the receiver's QR, so introduce our file server to it
    private fun link(host: String, port: Int, rt: String) = thread {
        if (pullMode) {   // we joined the SENDER's hotspot: just download from it
            emit(JSONObject().put("t", "linked").put("route", route(host, direct)))
            download(host, port, rt)
            return@thread
        }
        try {
            val sp = srv?.localPort ?: throw java.io.IOException("sender not ready")
            cancelled = false; paused = false; peerHost = host; peerPort = port; peerTok = rt
            var tries = 0
            while (true) {
                try { val sk = open(host, port, "/hello?t=$rt&port=$sp&st=$tok"); sk.getInputStream().readBytes(); sk.close(); break }
                catch (e: Exception) { if (++tries >= 6) throw e; Thread.sleep(1000) }
            }
            emit(JSONObject().put("t", "linked").put("route", route(host, direct || legacyId >= 0)))
        } catch (e: Exception) {
            err("Could not reach the receiver: " + e.javaClass.simpleName + " " + (e.message ?: "") + ". Both phones must be on the same Wi-Fi or hotspot.")
        }
    }
    private fun download(host: String, port: Int, t: String) = thread {
        cancelled = false; paused = false; peerHost = host; peerPort = port; peerTok = t
        val pend = java.util.concurrent.ConcurrentHashMap.newKeySet<Uri>()   // incomplete files, removed on cancel/fail
        try {
            wifi(true)
            val ls = open(host, port, "/list?t=$t")
            val list = JSONArray(String(ls.getInputStream().readBytes())); ls.close()
            val n = list.length(); var total = 0L
            for (i in 0 until n) total += list.getJSONObject(i).getLong("s")
            val done = AtomicLong(0); val start = System.currentTimeMillis()
            val nameArr = arrayOfNulls<String>(n); val uriArr = arrayOfNulls<String>(n)

            // downloads ONE file; big files are split into several parallel connections
            fun one(i: Int) {
                val name = list.getJSONObject(i).getString("n"); val size = list.getJSONObject(i).getLong("s"); nameArr[i] = name
                val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "application/octet-stream"
                val u = entry(name, mime); pend.add(u); uriArr[i] = u.toString()
                val mine = AtomicLong(0)   // bytes of THIS file already counted in `done`
                fun add(k: Int) { mine.addAndGet(k.toLong()); prog("p", name, i + 1, n, done.addAndGet(k.toLong()), total, start) }
                try {
                    contentResolver.openFileDescriptor(u, "w")!!.use { pfd ->
                        val ch = FileOutputStream(pfd.fileDescriptor).channel
                        try { if (size > 0) android.system.Os.posix_fallocate(pfd.fileDescriptor, 0, size) } catch (e: Exception) {}
                        val parts = when {
                            size > (256L shl 20) -> 8
                            size > (32L shl 20) -> 6
                            size > (8L shl 20) -> 4
                            size > (2L shl 20) -> 2
                            else -> 1
                        }
                        val chunk = (size + parts - 1) / parts
                        val got = LongArray(parts)   // bytes already written per part: survives dropped connections
                        val fail = java.util.concurrent.atomic.AtomicReference<Exception?>(null)
                        val ws = (0 until parts).map { pi ->
                            thread {
                                try {
                                    val off = pi * chunk; val len = minOf(chunk, size - off)
                                    var fails = 0
                                    while (got[pi] < len && fail.get() == null) {
                                        try {
                                            open(host, port, "/f/$i?o=${off + got[pi]}&n=${len - got[pi]}&t=$t").use { sk ->
                                                val din = DataInputStream(sk.getInputStream())
                                                val buf = ByteArray(1 shl 20)
                                                while (got[pi] < len && fail.get() == null) {
                                                    while (paused && !cancelled) Thread.sleep(150)
                                                    if (cancelled) throw Cancelled()
                                                    val k = minOf(len - got[pi], buf.size.toLong()).toInt()
                                                    din.readFully(buf, 0, k)
                                                    ch.write(ByteBuffer.wrap(buf, 0, k), off + got[pi]); got[pi] = got[pi] + k.toLong(); fails = 0
                                                    add(k)
                                                }
                                            }
                                        } catch (e: Cancelled) { throw e }
                                        catch (e: Exception) {
                                            if (cancelled || ++fails > 40) throw e
                                            Thread.sleep(1500)   // link dropped: wait, then continue from got[pi], not from zero
                                        }
                                    }
                                } catch (e: Exception) { fail.set(e) }
                            }
                        }
                        ws.forEach { it.join() }
                        fail.get()?.let { throw it }
                    }
                } catch (e: Exception) {
                    if (cancelled || e is Cancelled) throw e
                    done.addAndGet(-mine.getAndSet(0))
                    contentResolver.openOutputStream(u)!!.use { out ->
                        open(host, port, "/f/$i?t=$t").use { sk ->
                            val din = DataInputStream(sk.getInputStream())
                            val buf = ByteArray(1 shl 20); var rem = size
                            while (rem > 0) {
                                while (paused && !cancelled) Thread.sleep(150)
                                if (cancelled) throw Cancelled()
                                val k = minOf(rem, buf.size.toLong()).toInt()
                                din.readFully(buf, 0, k); out.write(buf, 0, k); rem -= k
                                add(k)
                            }
                        }
                    }
                }
                contentResolver.update(u, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
                pend.remove(u)
            }

            // small files: 4 at a time (saves the per-file setup time); big files: one by one, each with parallel parts
            val small = (0 until n).filter { list.getJSONObject(it).getLong("s") <= (8L shl 20) }
            val big = (0 until n).filter { list.getJSONObject(it).getLong("s") > (8L shl 20) }
            if (small.isNotEmpty()) {
                val q = java.util.concurrent.ConcurrentLinkedQueue<Int>(small)
                val sfail = java.util.concurrent.atomic.AtomicReference<Exception?>(null)
                val sw = (0 until minOf(4, small.size)).map {
                    thread {
                        try { while (sfail.get() == null) { val i = q.poll() ?: break; one(i) } }
                        catch (e: Exception) { sfail.compareAndSet(null, e) }
                    }
                }
                sw.forEach { it.join() }
                sfail.get()?.let { throw it }
            }
            for (i in big) one(i)

            val secs = maxOf(0.1, (System.currentTimeMillis() - start) / 1000.0)
            val names = JSONArray(); nameArr.forEach { names.put(it) }
            val uris = JSONArray(); uriArr.forEach { uris.put(it) }
            emit(JSONObject().put("t", "pdone").put("size", total).put("names", names).put("uris", uris).put("avg", total / 1048576.0 / secs))
        } catch (e: Exception) {
            pend.forEach { try { contentResolver.delete(it, null, null) } catch (x: Exception) {} }   // cancelled or failed: remove incomplete files
            if (e is Cancelled || cancelled) emit(JSONObject().put("t", "cancelled").put("by", if (cancelled) "me" else "peer"))
            else err("Transfer failed: " + e.javaClass.simpleName + " " + (e.message ?: "") + ". Both phones must be on the same Wi-Fi or hotspot.")
        } finally { wifi(false) }
    }

    // ---------- Fast mode: direct Wi-Fi link between the phones (no router needed) ----------
    private var hotspot: WifiManager.LocalOnlyHotspotReservation? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { startHotspot() }
    private fun fastPerms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.NEARBY_WIFI_DEVICES)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    private fun ensureServer() {
        if (srv == null) {
            tok = java.lang.Long.toHexString(java.util.Random().nextLong() and 0xffffffffL)
            srv = ServerSocket(0, 50); serve(); wifi(true); svc(true)
        }
    }
    private fun hotIp(): String {
        var dot1 = ""
        for (n in NetworkInterface.getNetworkInterfaces()) for (a in n.inetAddresses) {
            if (a !is Inet4Address || a.isLoopbackAddress || !a.isSiteLocalAddress) continue
            val nm = n.name.lowercase()
            if (nm.startsWith("ap") || nm.startsWith("swlan") || nm.startsWith("softap") || nm.startsWith("p2p")) return a.hostAddress ?: ""
            if (a.address[3] == 1.toByte()) dot1 = a.hostAddress ?: ""
        }
        return dot1
    }
    private var p2pMgr: android.net.wifi.p2p.WifiP2pManager? = null
    private var p2pCh: android.net.wifi.p2p.WifiP2pManager.Channel? = null
    @Volatile private var useLoh = false
    @Volatile private var p2pLabel = ""
    private fun stopHotspot() {
        try { hotspot?.close() } catch (e: Exception) {}; hotspot = null
        try { val m = p2pMgr; val c = p2pCh; if (m != null && c != null) { m.cancelConnect(c, null); m.removeGroup(c, null) } } catch (e: Exception) {}
        p2pMgr = null; p2pCh = null; p2pLabel = ""
    }
    // InShare-style Fast mode: a Wi-Fi Direct group pinned to 5 GHz (needs no router, no popup on the host)
    @Suppress("MissingPermission")
    private fun startP2pGroup(band: Int, label: String, fallback: () -> Unit) {
        try {
            val m = getSystemService(Context.WIFI_P2P_SERVICE) as android.net.wifi.p2p.WifiP2pManager
            val ch = m.initialize(this, Looper.getMainLooper(), null)
            val rnd = java.util.Random()
            val chars = "abcdefghjkmnpqrstuvwxyz23456789"
            fun rs(n: Int) = (1..n).map { chars[rnd.nextInt(chars.length)] }.joinToString("")
            val ssid = "DIRECT-" + (if (band == android.net.wifi.p2p.WifiP2pConfig.GROUP_OWNER_BAND_5GHZ) "50" else "24") + "-" + rs(8); val pass = rs(8)
            val cfg = android.net.wifi.p2p.WifiP2pConfig.Builder()
                .setNetworkName(ssid).setPassphrase(pass).enablePersistentMode(false).setGroupOperatingBand(band).build()
            p2pMgr = m; p2pCh = ch
            val done = java.util.concurrent.atomic.AtomicBoolean(false)
            fun fail() { if (done.compareAndSet(false, true)) { stopHotspot(); Handler(Looper.getMainLooper()).post { fallback() } } }
            m.removeGroup(ch, null)
            Handler(Looper.getMainLooper()).postDelayed({
                try {
                    m.createGroup(ch, cfg, object : android.net.wifi.p2p.WifiP2pManager.ActionListener {
                        override fun onSuccess() {
                            thread {
                                var h = ""
                                repeat(25) { if (h.isEmpty()) { h = hotIp(); if (h.isEmpty()) Thread.sleep(400) } }
                                if (h.isEmpty()) { fail(); return@thread }
                                if (!done.compareAndSet(false, true)) return@thread
                                p2pLabel = label
                                ensureServer()
                                fun b64(x: String) = android.util.Base64.encodeToString(x.toByteArray(), android.util.Base64.NO_WRAP or android.util.Base64.URL_SAFE)
                                emit(JSONObject().put("t", "qr").put("qr", (if (hostAsSender) "FT5" else "FT4") + "|$h|${srv!!.localPort}|$tok|${b64(ssid)}|${b64(pass)}|1|"))
                            }
                        }
                        override fun onFailure(reason: Int) { fail() }
                    })
                } catch (e: Exception) { fail() }
            }, 600)
            Handler(Looper.getMainLooper()).postDelayed({ if (!done.get()) fail() }, 10000)
        } catch (e: Exception) { stopHotspot(); fallback() }
    }
    // joiner side: join the other phone's Wi-Fi Direct group by name+password (no popup); falls back to the old way
    @Suppress("MissingPermission")
    private fun p2pJoin(port: Int, rt: String, ssid: String, pass: String, fallback: () -> Unit) {
        try {
            status("Connecting over Wi-Fi Direct...")
            val m = getSystemService(Context.WIFI_P2P_SERVICE) as android.net.wifi.p2p.WifiP2pManager
            val ch = m.initialize(this, Looper.getMainLooper(), null)
            p2pMgr = m; p2pCh = ch
            val cfg = android.net.wifi.p2p.WifiP2pConfig.Builder()
                .setDeviceAddress(android.net.MacAddress.fromString("02:00:00:00:00:00"))
                .setNetworkName(ssid).setPassphrase(pass).build()
            m.cancelConnect(ch, null); m.removeGroup(ch, null); Thread.sleep(700)
            val latch = java.util.concurrent.CountDownLatch(1); val ok = java.util.concurrent.atomic.AtomicBoolean(false)
            m.connect(ch, cfg, object : android.net.wifi.p2p.WifiP2pManager.ActionListener {
                override fun onSuccess() { ok.set(true); latch.countDown() }
                override fun onFailure(reason: Int) { latch.countDown() }
            })
            latch.await(8, java.util.concurrent.TimeUnit.SECONDS)
            if (!ok.get()) { stopHotspot(); fallback(); return }
            var host: String? = null
            val end = System.currentTimeMillis() + 25000
            while (host == null && System.currentTimeMillis() < end && !cancelled) {
                val got = java.util.concurrent.CountDownLatch(1)
                m.requestConnectionInfo(ch) { info -> if (info != null && info.groupFormed && !info.isGroupOwner) host = info.groupOwnerAddress?.hostAddress; got.countDown() }
                got.await(1, java.util.concurrent.TimeUnit.SECONDS)
                if (host == null) Thread.sleep(500)
            }
            val h = host
            if (h == null) { stopHotspot(); fallback(); return }
            direct = true; p2pLabel = "Wi-Fi Direct"
            link(h, port, rt)
        } catch (e: Exception) { stopHotspot(); fallback() }
    }
    private fun unbind() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            netCb?.let { cm.unregisterNetworkCallback(it) }; netCb = null
            cm.bindProcessToNetwork(null)
        } catch (e: Exception) {}
        try {   // leave the receiver's temporary Wi-Fi and go back to the normal one
            if (legacyId >= 0) {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION") wm.removeNetwork(legacyId); legacyId = -1; wm.reconnect()
            }
        } catch (e: Exception) {}
    }
    private var wantHotspot = false
    override fun onResume() {
        super.onResume()
        emit(JSONObject().put("t", "perm"))
        if (wantHotspot) {
            val lm = getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
            if (lm.isLocationEnabled) { wantHotspot = false; startHotspot() }
        }
    }
    private fun startHotspot(attempt: Int = 0) {
        val skipP2p = useLoh; useLoh = false
        if (Build.VERSION.SDK_INT < 33) {   // Android 12 and older cannot start a hotspot while Location is switched off
            val lm = getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
            if (!lm.isLocationEnabled) {
                wantHotspot = true
                emit(JSONObject().put("t", "needloc"))
                try { startActivity(Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS)) } catch (e: Exception) {}
                return
            }
        }
        if (attempt == 0 && !skipP2p) {
            startP2pGroup(android.net.wifi.p2p.WifiP2pConfig.GROUP_OWNER_BAND_5GHZ, "Wi-Fi Direct 5 GHz") {
                startP2pGroup(android.net.wifi.p2p.WifiP2pConfig.GROUP_OWNER_BAND_AUTO, "Wi-Fi Direct") { useLoh = true; startHotspot(0) }
            }
            return
        }
        stopHotspot()
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(reservation: WifiManager.LocalOnlyHotspotReservation?) {
                    val r = reservation ?: return
                    hotspot = r
                    var ssid = ""; var pass = ""
                    if (Build.VERSION.SDK_INT >= 30) { val c = r.softApConfiguration; ssid = c.ssid ?: ""; pass = c.passphrase ?: "" }
                    else { @Suppress("DEPRECATION") val c = r.wifiConfiguration; ssid = c?.SSID ?: ""; pass = c?.preSharedKey ?: "" }
                    ssid = ssid.trim('"'); pass = pass.trim('"')
                    thread {
                        var h = ""
                        repeat(20) { if (h.isEmpty()) { h = hotIp(); if (h.isEmpty()) Thread.sleep(400) } }
                        if (h.isEmpty()) { stopHotspot(); err("Fast mode: the hotspot started but has no address yet. Please try again."); return@thread }
                        ensureServer()
                        val sec = if (Build.VERSION.SDK_INT >= 30) r.softApConfiguration.securityType else 1
                        fun b64(x: String) = android.util.Base64.encodeToString(x.toByteArray(), android.util.Base64.NO_WRAP or android.util.Base64.URL_SAFE)
                        emit(JSONObject().put("t", "qr").put("qr", (if (hostAsSender) "FT5" else "FT4") + "|$h|${srv!!.localPort}|$tok|${b64(ssid)}|${b64(pass)}|$sec|${ip().let { if (it == h) "" else it }}"))
                    }
                }
                override fun onFailed(reason: Int) {
                    if (attempt == 0) Handler(Looper.getMainLooper()).postDelayed({ startHotspot(1) }, 1200)   // first start often fails: retry once by itself
                    else err("Fast mode could not start (code $reason). Turn on Location, turn off any hotspot, then try again.")
                }
                override fun onStopped() {}
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) { err("Fast mode failed: " + e.javaClass.simpleName + " " + (e.message ?: "")) }
    }
    // sender side: join the receiver's direct Wi-Fi, then introduce ourselves
    private fun specJoin(ip0: String, port: Int, rt: String, ssid: String, pass: String, sec: Int = 1, ipN: String = "", attempt: Int = 0) {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val sb = WifiNetworkSpecifier.Builder().setSsid(ssid)
            if (sec == 3) sb.setWpa3Passphrase(pass) else sb.setWpa2Passphrase(pass)
            if (attempt == 1) sb.setIsHiddenSsid(true)   // 2nd try: directed probe, connects even if the scan list misses the hotspot
            val spec = sb.build()
            val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).setNetworkSpecifier(spec).build()
            netCb?.let { try { cm.unregisterNetworkCallback(it) } catch (e: Exception) {} }
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    cm.bindProcessToNetwork(network)
                    thread {
                        var gw: String? = null
                        repeat(12) {
                            if (gw == null) {
                                gw = cm.getLinkProperties(network)?.routes
                                    ?.firstOrNull { it.hasGateway() && it.gateway is Inet4Address }?.gateway?.hostAddress
                                if (gw == null) Thread.sleep(250)
                            }
                        }
                        direct = true
                        link(gw ?: ip0, port, rt)
                    }
                }
                override fun onUnavailable() {
                thread {
                    val near = nearbySsids()
                    // the QR name may differ from what the receiver really broadcasts: try the visible AndroidShare_ network
                    val alt = near.firstOrNull { it.startsWith("AndroidShare_") && it != ssid }
                    if (attempt == 0 && alt != null) { status("Found " + alt + ", trying it..."); specJoin(ip0, port, rt, alt, pass, sec, ipN, 1); return@thread }
                    if (attempt == 0 && ipN.isEmpty()) { status("Retrying direct Wi-Fi..."); specJoin(ip0, port, rt, ssid, pass, sec, ipN, 1); return@thread }
                    if (ipN.isNotEmpty()) { status("Trying the normal Wi-Fi route..."); link(ipN, port, rt); return@thread }
                    manualJoin(ip0, port, rt, ssid, pass)
                }
            }
            }
            netCb = cb
            cm.requestNetwork(req, cb, if (attempt == 0) 15000 else 10000)
        } catch (e: Exception) { err("Fast mode failed: " + e.javaClass.simpleName + " " + (e.message ?: "")) }
    }

    private fun icon(d: android.graphics.drawable.Drawable): String {
        val sz = 64
        val bm = android.graphics.Bitmap.createBitmap(sz, sz, android.graphics.Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, sz, sz); d.draw(android.graphics.Canvas(bm))
        val bo = java.io.ByteArrayOutputStream(); bm.compress(android.graphics.Bitmap.CompressFormat.PNG, 90, bo)
        return android.util.Base64.encodeToString(bo.toByteArray(), android.util.Base64.NO_WRAP)
    }

    // split apps: pack base + all split APKs into ONE .apks file so nothing is missing
    private fun bundle(ai: android.content.pm.ApplicationInfo, label: String): File {
        val out = File(cacheDir, "$label.apks")
        ZipOutputStream(BufferedOutputStream(FileOutputStream(out), 1 shl 20)).use { z ->
            z.setLevel(0)
            (listOf(ai.sourceDir) + (ai.splitSourceDirs ?: emptyArray<String>())).forEach { p ->
                val f = File(p); z.putNextEntry(ZipEntry(f.name))
                f.inputStream().use { it.copyTo(z, 1 shl 20) }; z.closeEntry()
            }
        }
        return out
    }

    // ---------- Sender: join the receiver's direct Wi-Fi quickly (ShareMe-style), with step-by-step status ----------
    private var legacyId = -1
    @Volatile private var hostAsSender = false   // new fast mode: the SENDER makes the hotspot, the receiver scans its QR
    @Volatile private var pullMode = false       // receiver joined the sender's hotspot: download from it
    @Volatile private var direct = false   // true only when we really joined the receiver's own hotspot
    private fun status(m: String) = emit(JSONObject().put("t", "status").put("msg", m))
    @Suppress("DEPRECATION")
    private fun bindToSubnet(ip0: String) {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val pre = ip0.substringBeforeLast('.')
            for (n in cm.allNetworks) {
                val lp = cm.getLinkProperties(n) ?: continue
                if (lp.linkAddresses.any { (it.address.hostAddress ?: "").startsWith("$pre.") }) { cm.bindProcessToNetwork(n); return }
            }
        } catch (e: Exception) {}
    }
    // Silent join with the classic Wi-Fi API (works because the app targets an older Android level). No pop-up, usually under 2 seconds.
    @Suppress("DEPRECATION")
    private fun legacyJoin(ssid: String, pass: String, ip0: String): Boolean {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (!wm.isWifiEnabled) wm.isWifiEnabled = true
            val q = "\"" + ssid + "\""
            val conf = android.net.wifi.WifiConfiguration()
            conf.SSID = q; conf.preSharedKey = "\"" + pass + "\""
            conf.allowedKeyManagement.set(android.net.wifi.WifiConfiguration.KeyMgmt.WPA_PSK)
            wm.configuredNetworks?.filter { it.SSID == q }?.forEach { wm.removeNetwork(it.networkId) }
            val id = wm.addNetwork(conf)
            if (id < 0) return false
            legacyId = id
            wm.disconnect(); wm.enableNetwork(id, true); wm.reconnect()
            val end = System.currentTimeMillis() + 15000
            while (System.currentTimeMillis() < end) {
                val g = wm.dhcpInfo.gateway
                if (g != 0 && "${g and 255}.${(g shr 8) and 255}.${(g shr 16) and 255}.${(g shr 24) and 255}" == ip0) { bindToSubnet(ip0); return true }
                Thread.sleep(250)
            }
        } catch (e: Exception) {}
        return false
    }
    // Last resort that works on every phone: user picks the hotspot in Wi-Fi settings (password is copied), app continues by itself
    @Suppress("DEPRECATION")
    private fun onHotspotSubnet(ip0: String): Boolean = try {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val pre = ip0.substringBeforeLast('.') + "."
        cm.allNetworks.any { n -> cm.getLinkProperties(n)?.linkAddresses?.any { (it.address.hostAddress ?: "").startsWith(pre) } == true }
    } catch (e: Exception) { false }
    private fun manualJoin(ip0: String, port: Int, rt: String, ssid: String, pass: String) {
        try { (getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("pw", pass)) } catch (e: Exception) {}
        status("Tap \"" + ssid + "\" in Wi-Fi settings. Password (copied): " + pass + " - then come back, the app continues by itself.")
        runOnUiThread { try { startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)) } catch (e: Exception) {} }
        thread {
            val end = System.currentTimeMillis() + 120000
            while (System.currentTimeMillis() < end && !cancelled) {
                if (onHotspotSubnet(ip0)) { bindToSubnet(ip0); direct = true; link(ip0, port, rt); return@thread }
                Thread.sleep(1000)
            }
            err("Could not connect to \"" + ssid + "\". Password: " + pass)
        }
    }
    @Suppress("DEPRECATION")
    private fun nearbySsids(): List<String> = try {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wm.startScan(); Thread.sleep(1500)
        wm.scanResults.map { it.SSID ?: "" }.filter { it.isNotEmpty() }.distinct()
    } catch (e: Exception) { emptyList() }
    private fun joinAndLink(ip0: String, port: Int, rt: String, ssid: String, pass: String, sec: Int = 1, ipN: String = "") {
        thread {
            direct = false
            val wmx = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (!wmx.isWifiEnabled) {
                status("Turn Wi-Fi ON - joining the receiver's hotspot needs it")
                runOnUiThread { try { startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)) } catch (e: Exception) {} }
                val endW = System.currentTimeMillis() + 30000
                while (!wmx.isWifiEnabled && System.currentTimeMillis() < endW) Thread.sleep(500)
                Thread.sleep(1500)
            }
            status("Connecting to the receiver...")
            val classic = {
                if (ip0.isNotEmpty() && applicationInfo.targetSdkVersion < 29 && legacyJoin(ssid, pass, ip0)) {
                    status("Joined the direct Wi-Fi")
                    link(ip0, port, rt)
                } else {
                    status("Asking Android to join " + ssid + "... tap Connect if it asks")
                    specJoin(ip0, port, rt, ssid, pass, sec, ipN)
                }
            }
            if (ssid.startsWith("DIRECT-")) p2pJoin(port, rt, ssid, pass, classic) else classic()
        }
    }

    inner class Bridge {
        @JavascriptInterface fun permState(): String {
            fun g(x: String) = checkSelfPermission(x) == PackageManager.PERMISSION_GRANTED
            val o = JSONObject().put("loc", g(Manifest.permission.ACCESS_FINE_LOCATION))
            o.put("nearby", if (Build.VERSION.SDK_INT >= 33) g(Manifest.permission.NEARBY_WIFI_DEVICES) else JSONObject.NULL)
            o.put("notif", if (Build.VERSION.SDK_INT >= 33) g(Manifest.permission.POST_NOTIFICATIONS) else JSONObject.NULL)
            return o.toString()
        }
        @JavascriptInterface fun askPerm(w: String) {
            val x = when (w) { "loc" -> Manifest.permission.ACCESS_FINE_LOCATION; "nearby" -> if (Build.VERSION.SDK_INT >= 33) Manifest.permission.NEARBY_WIFI_DEVICES else return; else -> if (Build.VERSION.SDK_INT >= 33) Manifest.permission.POST_NOTIFICATIONS else return }
            lastAsked = x; runOnUiThread { oneLauncher.launch(x) }
        }
        @JavascriptInterface fun pick() { runOnUiThread { picker.launch(arrayOf("*/*")) } }
        @JavascriptInterface fun clear() { items.clear(); emitFiles() }
        @JavascriptInterface fun start(): String {
            ensureServer()
            return JSONObject().put("ip", ip()).put("port", srv!!.localPort).put("tok", tok).toString()
        }
        @JavascriptInterface fun fastSend() { hostAsSender = true; runOnUiThread { permLauncher.launch(fastPerms()) } }
        @JavascriptInterface fun fastStop() { hostAsSender = false; stopHotspot() }
        @JavascriptInterface fun fast(on: Boolean) { hostAsSender = false; if (!on) wantHotspot = false; runOnUiThread { if (on) permLauncher.launch(fastPerms()) else stopHotspot() } }
        @JavascriptInterface fun wifiCaps(): String {
            return try {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                var std = "Wi-Fi 4 or older"
                if (Build.VERSION.SDK_INT >= 33 && wm.isWifiStandardSupported(8)) std = "Wi-Fi 7"
                else if (Build.VERSION.SDK_INT >= 30 && wm.isWifiStandardSupported(6)) std = "Wi-Fi 6"
                else if (Build.VERSION.SDK_INT >= 30 && wm.isWifiStandardSupported(5)) std = "Wi-Fi 5"
                std + (if (wm.is5GHzBandSupported()) ", 5 GHz" else ", 2.4 GHz only")
            } catch (e: Exception) { "" }
        }
        @JavascriptInterface fun apps() {
            thread {
                val pm = packageManager
                val ri = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                val seen = HashSet<String>(); val tmp = ArrayList<JSONObject>()
                for (r in ri) {
                    val ai = r.activityInfo.applicationInfo
                    if (!seen.add(ai.packageName)) continue
                    val sp = ai.splitSourceDirs
                    var size = File(ai.sourceDir).length(); sp?.forEach { size += File(it).length() }
                    tmp.add(JSONObject().put("p", ai.packageName).put("n", r.loadLabel(pm).toString())
                        .put("s", size).put("sp", sp?.size ?: 0).put("i", icon(r.loadIcon(pm))))
                }
                tmp.sortBy { it.getString("n").lowercase() }
                emit(JSONObject().put("t", "apps").put("list", JSONArray(tmp)))
            }
        }
        @JavascriptInterface fun addApps(json: String) {
            thread {
                val pm = packageManager; val arr = JSONArray(json)
                for (i in 0 until arr.length()) {
                    try {
                        val ai = pm.getApplicationInfo(arr.getString(i), 0)
                        val label = pm.getApplicationLabel(ai).toString().replace(Regex("[^A-Za-z0-9 _.-]"), "").trim().ifEmpty { ai.packageName }
                        if (ai.splitSourceDirs.isNullOrEmpty()) { val b = File(ai.sourceDir); items.add(Item(null, "$label.apk", b.length(), b.path)) }
                        else { val b = bundle(ai, label); items.add(Item(null, "$label.apks", b.length(), b.path)) }
                    } catch (e: Exception) { err("Could not add app: " + e.javaClass.simpleName + " " + (e.message ?: "")) }
                }
                emitFiles()
            }
        }
        @JavascriptInterface fun install(uri: String) {
            runOnUiThread {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(uri), "application/vnd.android.package-archive")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) { err("Open the file from Downloads > FileTransfer to install it.") }
            }
        }
        @JavascriptInterface fun pause(on: Boolean) { paused = on }
        @JavascriptInterface fun snapshot(): String = snap
        @JavascriptInterface fun minimize() { runOnUiThread { moveTaskToBack(true) } }
        @JavascriptInterface fun cancel() {
            cancelled = true; paused = false
            val h = peerHost; val pt = peerPort; val tk = peerTok
            thread {
                try { if (h.isNotEmpty()) Socket().use { sk -> sk.connect(InetSocketAddress(h, pt), 3000); sk.getOutputStream().write("GET /bye?t=$tk HTTP/1.1\r\nHost: $h\r\nConnection: close\r\n\r\n".toByteArray()); sk.getOutputStream().flush(); sk.getInputStream().read() } } catch (e: Exception) {}
                closeAll()
                emit(JSONObject().put("t", "cancelled").put("by", "me"))
            }
        }
        @JavascriptInterface fun scan() {
            runOnUiThread {
                scanner.launch(Intent(this@MainActivity, ScanActivity::class.java))
            }
        }
        @JavascriptInterface fun stop() {
            try { srv?.close() } catch (e: Exception) {}
            srv = null; items.clear(); wifi(false); stopHotspot(); unbind(); svc(false); cancelled = false; paused = false; snap = ""; cacheDir.listFiles()?.filter { it.name.endsWith(".apks") }?.forEach { it.delete() }
        }
    }
}
