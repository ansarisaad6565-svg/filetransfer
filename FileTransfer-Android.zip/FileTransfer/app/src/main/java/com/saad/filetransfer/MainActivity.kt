package com.saad.filetransfer

import android.content.ContentValues
import android.content.Intent
import android.content.Context
import android.Manifest
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataInputStream
import java.io.File
import java.io.BufferedOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread

class Cancelled : java.io.IOException("cancelled")

data class Item(val uri: Uri?, val name: String, val size: Long, val path: String? = null)

class MainActivity : ComponentActivity() {
    companion object {
        @Volatile var cur: WebView? = null
        @Volatile var snap: String = ""
        @Volatile var paused = false
        @Volatile var cancelled = false
        @Volatile var peerHost = ""
        @Volatile var peerPort = 0
        @Volatile var peerTok = ""
        val socks = java.util.concurrent.CopyOnWriteArrayList<Socket>()
    }
    private var wake: android.os.PowerManager.WakeLock? = null
    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private var lastAsked = ""
    private val oneLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        // denied for good ("don't ask again"): send the user to the app's permission page
        if (!granted && lastAsked.isNotEmpty() && !shouldShowRequestPermissionRationale(lastAsked))
            try { startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (e: Exception) {}
        emit(JSONObject().put("t", "perm"))
    }
    private lateinit var wv: WebView
    private val items = java.util.concurrent.CopyOnWriteArrayList<Item>()
    private var srv: ServerSocket? = null
    private var tok = ""
    private val sent = AtomicLong(0)
    @Volatile private var t0 = 0L
    @Volatile private var last = 0L
    private var lock: WifiManager.WifiLock? = null
    private val BUF = 1 shl 20
    private val fin = AtomicBoolean(false)
    @Volatile private var peerDone = -1L         // sender: bytes the RECEIVER has really written (reported by its heartbeat)
    @Volatile private var recvDone = 0L          // receiver: bytes written so far
    @Volatile private var spT = 0L; @Volatile private var spD = 0L; @Volatile private var spE = 0.0   // smoothed speed
    private fun resetProgress() { peerDone = -1L; recvDone = 0L; spT = 0L; spD = 0L; spE = 0.0 }
    // speed of the last ~second (smoothed), not the average since the start: shows the real link speed and ignores pauses
    private fun smoothSpeed(done: Long, now: Long, start: Long): Double {
        if (spT == 0L || now - spT > 3000 || done < spD) {
            spT = now; spD = done
            if (spE == 0.0) spE = done / 1048576.0 / maxOf(0.1, (now - start) / 1000.0)
            return spE
        }
        val dt = now - spT
        if (dt >= 400) {
            val inst = (done - spD) / 1048576.0 / (dt / 1000.0)
            spE = if (spE == 0.0) inst else spE * 0.6 + inst * 0.4
            spT = now; spD = done
        }
        return spE
    }
    private fun peerProg(done: Long, total: Long, sp: Double) {
        emit(JSONObject().put("t", "s").put("name", curName).put("i", curIdx).put("n", items.size).put("done", done)
            .put("total", total).put("speed", sp).put("paused", paused).put("eta", if (sp > 0) maxOf(0L, total - done) / 1048576.0 / sp else 0.0))
        TransferService.update(applicationContext, "Sending " + curName + " - " + String.format(java.util.Locale.US, "%.1f", sp) + " MB/s" + (if (paused) " (paused)" else ""),
            if (total > 0) (done * 100 / total).toInt() else 0)
    }
    @Volatile private var curName = ""
    @Volatile private var curIdx = 0
    @Volatile private var lastN = 0L
    @Volatile private var hostSsid = ""   // Wi-Fi Direct name/password stay the same for the whole host session,
    @Volatile private var hostPass = ""   // so a restarted group is still reachable with the QR the other phone already scanned
    private val cancelSent = AtomicBoolean(false)       // so the "cancelled" message is shown only once
    @Volatile private var cancelBy = "me"
    @Volatile private var lastRp = false                 // last pause state told to us by the receiver
    private fun cancelUi(by: String) { if (cancelSent.compareAndSet(false, true)) emit(JSONObject().put("t", "cancelled").put("by", by)) }
    private fun pauseUi() = emit(JSONObject().put("t", "pause").put("paused", paused))

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { us ->
        us.forEach { u ->
            contentResolver.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) items.add(Item(u,
                    c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)),
                    c.getLong(c.getColumnIndexOrThrow(OpenableColumns.SIZE))))
            }
        }
        emitFiles()
    }

    private val scanner = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val txt = if (r.resultCode == RESULT_OK) r.data?.getStringExtra("t") else null
        if (txt == null || txt.startsWith("WIFI:") || txt.startsWith("FT1") || txt.startsWith("FT2")) dropPrewarm()
        if (txt != null) {
            scanAt = System.currentTimeMillis()
            pullMode = false
            if (txt.startsWith("WIFI:")) {   // a normal phone-hotspot "Share QR code": join it from inside the app
                val w = wifiQr(txt)
                val t = (w["T"] ?: "WPA").uppercase()
                withJoinPerms { joinHotspotOnly(w["S"] ?: "", w["P"] ?: "", if (t.contains("SAE") || t == "WPA3") 3 else if (t == "NOPASS" || t.isEmpty()) 0 else 1) }
                return@registerForActivityResult
            }
            val p = txt.split("|")
            if (p.size == 4 && p[0] == "FT1") download(p[1], p[2].toIntOrNull() ?: 0, p[3])
            else if (p.size == 4 && p[0] == "FT2") link(p[1], p[2].toIntOrNull() ?: 0, p[3])
            else if (p.size >= 7 && p[0] == "FT4") {
                val ssid4 = String(android.util.Base64.decode(p[4], android.util.Base64.URL_SAFE))
                val pass4 = String(android.util.Base64.decode(p[5], android.util.Base64.URL_SAFE))
                withJoinPerms { joinAndLink(p[1], p[2].toIntOrNull() ?: 0, p[3], ssid4, pass4, p[6].toIntOrNull() ?: 1, p.getOrElse(7) { "" }, p.getOrElse(8) { "" }) }
            }
            else if (p.size >= 7 && p[0] == "FT5") {
                val ssid5 = String(android.util.Base64.decode(p[4], android.util.Base64.URL_SAFE))
                val pass5 = String(android.util.Base64.decode(p[5], android.util.Base64.URL_SAFE))
                withJoinPerms { pullMode = true; stopHotspot(); joinAndLink(p[1], p[2].toIntOrNull() ?: 0, p[3], ssid5, pass5, p[6].toIntOrNull() ?: 1, p.getOrElse(7) { "" }, p.getOrElse(8) { "" }) }
            }
            else if (p.size == 6 && p[0] == "FT3") joinAndLink(p[1], p[2].toIntOrNull() ?: 0, p[3], p[4], p[5])
            else err("That is not a File Transfer QR code.")
        }
    }

    // FIX: the phone that JOINS the direct Wi-Fi (sender) also needs Location / Nearby-devices permission,
    // otherwise Android's Wi-Fi scan finds nothing and shows "device not found".
    private var afterPerm: (() -> Unit)? = null
    private val joinPermLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val go = afterPerm; afterPerm = null; go?.invoke()
    }
    private fun askAll() {
        val need = (fastPerms().toList() + Manifest.permission.CAMERA).filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) joinPermLauncher.launch(need.toTypedArray())
    }
    private fun withJoinPerms(go: () -> Unit) {
        val need = fastPerms().any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need) { afterPerm = go; joinPermLauncher.launch(fastPerms()) } else go()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        wv = WebView(this)
        cur = wv
        setContentView(wv)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.loadUrl("file:///android_asset/index.html")
        try {
            val f = android.content.IntentFilter().apply { addAction(WifiManager.WIFI_STATE_CHANGED_ACTION); addAction("android.location.MODE_CHANGED"); addAction("android.location.PROVIDERS_CHANGED") }
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(sysRcv, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(sysRcv, f)
        } catch (e: Exception) {}
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (snap.isNotEmpty()) moveTaskToBack(true) else wv.evaluateJavascript("goBack()") { if (it != "true") finish() } }
        })
    }

    private val sysRcv = object : android.content.BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { emit(JSONObject().put("t", "perm")) }
    }
    override fun onDestroy() { try { unregisterReceiver(sysRcv) } catch (e: Exception) {}; if (cur === wv) cur = null; super.onDestroy() }
    private fun emit(o: JSONObject) {
        val t = o.optString("t")
        if (t == "s" || t == "p") snap = o.toString()
        else if (t == "sdone" || t == "pdone" || t == "err" || t == "cancelled") {
            snap = ""
            TransferService.update(applicationContext, if (t == "sdone" || t == "pdone") "Transfer complete" else "Transfer stopped", -1)
        }
        val w = cur ?: return
        w.post { w.evaluateJavascript("onNative($o)", null) }
    }
    private fun closeAll(keep: Socket? = null) {
        socks.forEach { if (it !== keep) try { it.close() } catch (e: Exception) {} }
        socks.removeAll { it.isClosed }
    }
    private fun svc(on: Boolean) {
        try {
            if (on) {
                startForegroundService(Intent(this, TransferService::class.java))
                if (wake == null) wake = (getSystemService(Context.POWER_SERVICE) as android.os.PowerManager)
                    .newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "ft:xfer").apply { setReferenceCounted(false) }
                wake?.acquire(4 * 3600 * 1000L)
            } else {
                stopService(Intent(this, TransferService::class.java))
                if (wake?.isHeld == true) wake?.release()
            }
        } catch (e: Exception) {}
    }
    private fun err(m: String) = emit(JSONObject().put("t", "err").put("msg", m))
    private fun emitFiles() {
        val a = JSONArray(); items.forEach { a.put(JSONObject().put("n", it.name).put("s", it.size)) }
        emit(JSONObject().put("t", "files").put("list", a))
    }
    private fun wifi(on: Boolean) {
        if (on) {
            if (lock == null) lock = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
                .createWifiLock(if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY else WifiManager.WIFI_MODE_FULL_HIGH_PERF, "ft").apply { setReferenceCounted(false) }
            lock?.acquire()
        } else if (lock?.isHeld == true) lock?.release()
    }
    private fun prog(t: String, name: String, i: Int, n: Int, done: Long, total: Long, start: Long) {
        val now = System.currentTimeMillis()
        if (now - last < 200 && done < total) return
        last = now
        if (t == "p") recvDone = done
        val sp = smoothSpeed(done, now, start)
        emit(JSONObject().put("t", t).put("name", name).put("i", i).put("n", n).put("done", done)
            .put("total", total).put("speed", sp).put("paused", paused).put("eta", if (sp > 0) (total - done) / 1048576.0 / sp else 0.0))
        if (now - lastN > 1000 || done >= total) { lastN = now; TransferService.update(applicationContext, (if (t == "s") "Sending " else "Receiving ") + name + " - " + String.format("%.1f", sp) + " MB/s" + (if (paused) " (paused)" else ""),
            if (total > 0) (done * 100 / total).toInt() else 0) }
    }
    @Suppress("DEPRECATION")
    private fun route(peer: String, forced: Boolean = false): String = try {
        if (p2pMgr != null && p2pLabel.isNotEmpty()) p2pLabel + viaIface(peer) else {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val g = wm.dhcpInfo.gateway
        val gw = "${g and 255}.${(g shr 8) and 255}.${(g shr 16) and 255}.${(g shr 24) and 255}"
        var weHost = hotspot != null
        for (n in (NetworkInterface.getNetworkInterfaces()?.toList() ?: emptyList<NetworkInterface>())) { val nm = n.name.lowercase()
            if ((nm.startsWith("ap") || nm.startsWith("swlan") || nm.startsWith("softap") || nm.startsWith("p2p")) && n.inetAddresses.toList().any { it is Inet4Address }) weHost = true }
        val wi = wm.connectionInfo; val f = wi.frequency
        val band = if (f >= 5900) "6 GHz" else if (f >= 4900) "5 GHz" else if (f > 0) "2.4 GHz" else ""
        val info = if (band.isNotEmpty() && gw == peer) " [$band, ${wi.linkSpeed} Mbps]" else ""
        if (forced || weHost) "Direct Wi-Fi" + info
        else if (gw == peer) "Direct Wi-Fi (hotspot)" + info
        else "Wi-Fi network (via router)" + (if (band.isNotEmpty()) " [$band, ${wi.linkSpeed} Mbps]" else "")
        }
    } catch (e: Exception) { if (forced) "Direct Wi-Fi" else "Wi-Fi network" }
    // parse "WIFI:T:WPA;S:name;P:password;;" (the QR that Android/MIUI hotspot screens show)
    private fun wifiQr(t: String): Map<String, String> {
        val out = HashMap<String, String>(); val fields = ArrayList<String>(); val cur = StringBuilder(); var esc = false
        for (ch in t.substring(5)) {
            if (esc) { cur.append(ch); esc = false }
            else if (ch == '\\') esc = true
            else if (ch == ';') { fields.add(cur.toString()); cur.setLength(0) }
            else cur.append(ch)
        }
        if (cur.isNotEmpty()) fields.add(cur.toString())
        for (f in fields) { val i = f.indexOf(':'); if (i > 0) out[f.substring(0, i)] = f.substring(i + 1) }
        return out
    }
    @Suppress("DEPRECATION")
    private fun joinHotspotOnly(ssid: String, pass: String, sec: Int) {
        if (ssid.isEmpty()) { err("That Wi-Fi QR code has no network name."); return }
        thread {
            try {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                fun next() { status("Connected to \"" + ssid + "\". Now scan the QR code shown in the other phone's File Transfer app."); runOnUiThread { scanner.launch(Intent(this@MainActivity, ScanActivity::class.java)) } }
                if (wm.isWifiEnabled && (wm.connectionInfo?.ssid ?: "") == "\"" + ssid + "\"") { next(); return@thread }
                status("Joining \"" + ssid + "\"... tap Connect if Android asks")
                val sb = WifiNetworkSpecifier.Builder().setSsid(ssid)
                if (sec == 3) sb.setWpa3Passphrase(pass) else if (sec == 1) sb.setWpa2Passphrase(pass)
                val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                    .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).setNetworkSpecifier(sb.build()).build()
                netCb?.let { try { cm.unregisterNetworkCallback(it) } catch (e: Exception) {} }
                val cb = object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) { cm.bindProcessToNetwork(network); direct = false; next() }
                    override fun onUnavailable() { err("Could not join \"" + ssid + "\". Check the hotspot is ON and try again.") }
                }
                netCb = cb
                cm.requestNetwork(req, cb, 45000)
            } catch (e: Exception) { err("Could not join the hotspot: " + e.javaClass.simpleName + " " + (e.message ?: "")) }
        }
    }
    private fun ip(): String {
        var best = ""
        for (n in (NetworkInterface.getNetworkInterfaces()?.toList() ?: emptyList<NetworkInterface>())) for (a in n.inetAddresses)
            if (a is Inet4Address && !a.isLoopbackAddress && a.isSiteLocalAddress &&
                (best.isEmpty() || n.name.startsWith("wlan") || n.name.startsWith("ap"))) best = a.hostAddress ?: ""
        return best
    }

    // ---------- sender: raw-TCP HTTP server, 1 MB buffers ----------
    private fun serve() = thread(isDaemon = true) {
        val s = srv ?: return@thread
        while (!s.isClosed) {
            val c = try { s.accept() } catch (e: Exception) { break }
            socks.add(c); thread { try { handle(c) } catch (e: Exception) {} finally { try { c.close() } catch (e: Exception) {}; socks.remove(c) } }
        }
    }
    private fun handle(c: Socket) {
        c.sendBufferSize = 4 shl 20; c.tcpNoDelay = true
        val r = c.getInputStream().bufferedReader()
        val line = r.readLine() ?: return
        while (!r.readLine().isNullOrEmpty()) { }
        val p = line.split(" ").getOrNull(1) ?: return
        val o = c.getOutputStream()
        fun hdr(code: String, len: Long) = o.write("HTTP/1.1 $code\r\nContent-Length: $len\r\nConnection: close\r\n\r\n".toByteArray())
        val q = p.substringAfter('?', "").split('&').associate { it.substringBefore('=') to it.substringAfter('=', "") }
        if (q["t"] != tok) { hdr("403 Forbidden", 0); return }
        if (p.startsWith("/bye")) { cancelBy = "peer"; cancelled = true; paused = false; hdr("200 OK", 0); o.flush(); cancelUi("peer"); closeAll(c); return }
        if (cancelled && !p.startsWith("/hello")) { hdr("410 Gone", 0); return }
        if (p.startsWith("/ping")) {   // receiver asks every ~0.7 s: pause state goes both ways, 410 above tells it we cancelled
            val rp = q["rp"] == "1"
            if (rp != lastRp) { lastRp = rp; paused = rp; pauseUi() }
            val dd = q["d"]?.toLongOrNull(); val ss = q["sp"]?.toDoubleOrNull()
            if (dd != null && ss != null) {   // both phones now show the receiver's real numbers
                peerDone = dd
                val tot = items.sumOf { x -> x.size }
                if (tot > 0 && curName.isNotEmpty()) {
                    peerProg(minOf(dd, tot), tot, ss)
                    if (dd >= tot && fin.compareAndSet(false, true)) emit(JSONObject().put("t", "sdone").put("size", tot)
                        .put("names", JSONArray().also { a -> items.forEach { x -> a.put(x.name) } }))
                }
            }
            val pb = (if (paused) "P" else "R").toByteArray()
            hdr("200 OK", pb.size.toLong()); o.write(pb); o.flush(); return
        }
        if (p.startsWith("/hello")) {   // receiver side: the sender scanned our QR and tells us where its files are
            hdr("200 OK", 0); o.flush()
            val sp = q["port"]?.toIntOrNull(); val st = q["st"]
            if (sp != null && st != null) { cancelled = false; paused = false; emit(JSONObject().put("t", "linked").put("route", route(c.inetAddress.hostAddress ?: ""))); download(c.inetAddress.hostAddress ?: "", sp, st) }
            return
        }
        if (p.startsWith("/list")) {
            wifi(true)   // a receiver is downloading: fast radio mode from now on
            if (hotspot != null) emit(JSONObject().put("t", "linked").put("route", route(c.inetAddress.hostAddress ?: "", true)))
            val a = JSONArray(); items.forEach { a.put(JSONObject().put("n", it.name).put("s", it.size)) }
            val b = a.toString().toByteArray(); sent.set(0); t0 = 0; fin.set(false); lastRp = false; cancelSent.set(false); resetProgress()
            hdr("200 OK", b.size.toLong()); o.write(b)
        } else if (p.startsWith("/f/")) {
            val idx = p.substring(3).substringBefore("?").toInt()
            val item = items.getOrNull(idx) ?: return
            val off = q["o"]?.toLongOrNull() ?: 0L
            val len = q["n"]?.toLongOrNull() ?: (item.size - off)
            val total = items.sumOf { x -> x.size }
            hdr("200 OK", len)
            (if (item.path != null) FileInputStream(item.path) else contentResolver.openInputStream(item.uri!!)!!).use { ins ->
                var skipped = 0L
                while (skipped < off) { val sk = ins.skip(off - skipped); if (sk <= 0) break; skipped += sk }
                val buf = ByteArray(BUF)
                var rem = len
                while (rem > 0) {
                    while (paused && !cancelled) Thread.sleep(150); if (cancelled) break
                    val k = ins.read(buf, 0, minOf(rem, BUF.toLong()).toInt()); if (k < 0) break
                    o.write(buf, 0, k); rem -= k
                    val d = sent.addAndGet(k.toLong()); if (t0 == 0L) t0 = System.currentTimeMillis()
                    curName = item.name; curIdx = idx + 1
                    if (peerDone < 0) prog("s", item.name, idx + 1, items.size, d, total, t0)   // old receiver without heartbeat: local numbers
                }
            }
            o.flush()
            if (sent.get() >= total && (peerDone < 0 || peerDone >= total - (48L shl 20)) && fin.compareAndSet(false, true)) emit(JSONObject().put("t", "sdone").put("size", total)
                .put("names", JSONArray().also { a -> items.forEach { x -> a.put(x.name) } }))
        }
        o.flush()
    }

    // ---------- receiver: streams straight into MediaStore (Gallery) ----------
    private fun entry(name: String, mime: String): Uri {
        val (col, dir) = when {
            mime.startsWith("image/") -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_PICTURES
            mime.startsWith("video/") -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MOVIES
            mime.startsWith("audio/") -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MUSIC
            else -> MediaStore.Downloads.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_DOWNLOADS
        }
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name); put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "$dir/FileTransfer"); put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        return contentResolver.insert(col, v)!!
    }
    // raw socket: 2 MB receive window, no HTTP library overhead
    private fun open(host: String, port: Int, path: String, ct: Int = 6000): Socket {
        if (cancelled) throw Cancelled()
        socks.removeAll { it.isClosed }
        val s = Socket(); s.receiveBufferSize = 4 shl 20; s.tcpNoDelay = true; s.keepAlive = true; s.soTimeout = 20000
        socks.add(s)
        try {
            s.connect(InetSocketAddress(host, port), ct)
            s.getOutputStream().write("GET $path HTTP/1.1\r\nHost: $host\r\nConnection: close\r\n\r\n".toByteArray())
            val i = s.getInputStream(); var m = 0; val hb = StringBuilder()
            while (m < 4) {
                val b = i.read(); if (b < 0) throw java.io.IOException("closed")
                if (hb.length < 40) hb.append(b.toChar())
                val exp = if (m % 2 == 0) 13 else 10
                m = if (b == exp) m + 1 else if (b == 13) 1 else 0
            }
            val code = hb.toString().substringAfter(' ').take(3)
            if (code == "410") throw Cancelled()
            if (code != "200") throw java.io.IOException("HTTP $code")
        } catch (e: Exception) { socks.remove(s); try { s.close() } catch (x: Exception) {}; throw e }
        return s
    }
    // sender side: scanned the receiver's QR, so introduce our file server to it
    private fun link(host: String, port: Int, rt: String) = thread {
        if (pullMode) {   // we joined the SENDER's hotspot: just download from it
            emit(JSONObject().put("t", "linked").put("route", route(host, direct) + took()))
            download(host, port, rt)
            return@thread
        }
        try {
            val sp = srv?.localPort ?: throw java.io.IOException("sender not ready")
            cancelled = false; paused = false; cancelBy = "me"; cancelSent.set(false); resetProgress(); peerHost = host; peerPort = port; peerTok = rt
            var tries = 0
            while (true) {
                try { val sk = open(host, port, "/hello?t=$rt&port=$sp&st=$tok", 1200); sk.getInputStream().readBytes(); sk.close(); break }
                catch (e: Exception) { if (++tries >= 45) throw e; Thread.sleep(120) }   // retry quickly: the link is usable the moment Android finishes DHCP
            }
            wifi(true)   // fast radio mode only now that the link works
            emit(JSONObject().put("t", "linked").put("route", route(host, direct || legacyId >= 0) + took()))
        } catch (e: Exception) {
            err("Could not reach the receiver: " + e.javaClass.simpleName + " " + (e.message ?: "") + ". Both phones must be on the same Wi-Fi or hotspot.")
        }
    }
    private fun openRetry(host: String, port: Int, path: String, tries: Int = 12): Socket {
        var n = 0
        while (true) {
            try { return open(host, port, path, 2000) }
            catch (e: Cancelled) { throw e }
            catch (e: Exception) { if (cancelled || ++n >= tries * 2) throw e; Thread.sleep(150) }
        }
    }
    private fun download(host: String, port: Int, t: String) = thread {
        cancelled = false; paused = false; cancelBy = "me"; cancelSent.set(false); resetProgress(); peerHost = host; peerPort = port; peerTok = t
        val alive = AtomicBoolean(true)
        val pend = java.util.concurrent.ConcurrentHashMap.newKeySet<Uri>()   // incomplete files, removed on cancel/fail
        try {
            wifi(true)
            val ls = openRetry(host, port, "/list?t=$t")
            val list = JSONArray(String(ls.getInputStream().readBytes())); ls.close()
            // heartbeat: keeps pause/resume in sync on both phones and notices at once when the other phone cancels
            thread(isDaemon = true) {
                var lastSp = false; var refused = 0
                while (alive.get() && !cancelled) {
                    try {
                        val sk = open(host, port, "/ping?t=$t&rp=" + (if (paused) "1" else "0") + "&d=" + recvDone + "&sp=" + String.format(java.util.Locale.US, "%.2f", spE), 2500)
                        val b = try { sk.getInputStream().read() } finally { try { sk.close() } catch (x: Exception) {}; socks.remove(sk) }
                        refused = 0
                        val sp = (b == 80)
                        if (sp != lastSp) { lastSp = sp; paused = sp; pauseUi() }
                    } catch (e: Cancelled) {
                        if (alive.get() && !cancelled) { cancelBy = "peer"; cancelled = true; closeAll() }
                        break
                    } catch (e: java.net.ConnectException) {
                        // "refused" = the other phone closed its sender (cancelled / left). Other errors = weak link: keep trying
                        if ((e.message ?: "").contains("refused", true) && ++refused >= 3 && alive.get() && !cancelled) { cancelBy = "peer"; cancelled = true; closeAll(); break }
                    } catch (e: Exception) { }
                    try { Thread.sleep(700) } catch (e: InterruptedException) { break }
                }
            }
            val n = list.length(); var total = 0L
            for (i in 0 until n) total += list.getJSONObject(i).getLong("s")
            val done = AtomicLong(0); val start = System.currentTimeMillis()
            val nameArr = arrayOfNulls<String>(n); val uriArr = arrayOfNulls<String>(n)

            // downloads ONE file; big files are split into several parallel connections
            val qWait = AtomicLong(0); val wIdle = AtomicLong(0)   // meter: storage slow (reader waits for a free buffer) vs Wi-Fi slow (writer waits for data)
            fun one(i: Int) {
                val name = list.getJSONObject(i).getString("n"); val size = list.getJSONObject(i).getLong("s"); nameArr[i] = name
                val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "application/octet-stream"
                val u = entry(name, mime); pend.add(u); uriArr[i] = u.toString()
                val mine = AtomicLong(0)   // bytes of THIS file already counted in `done`
                fun add(k: Int) { mine.addAndGet(k.toLong()); prog("p", name, i + 1, n, done.addAndGet(k.toLong()), total, start) }
                try {
                    contentResolver.openFileDescriptor(u, "w")!!.use { pfd ->
                        val ch = FileOutputStream(pfd.fileDescriptor).channel
                        try { if (size > 0) android.system.Os.posix_fallocate(pfd.fileDescriptor, 0, size) } catch (e: Exception) {}
                        val parts = when {
                            size > (1L shl 30) -> 12
                            size > (256L shl 20) -> 10
                            size > (32L shl 20) -> 6
                            size > (8L shl 20) -> 4
                            size > (2L shl 20) -> 2
                            else -> 1
                        }
                        val chunk = (size + parts - 1) / parts
                        val got = LongArray(parts)   // bytes already written per part: survives dropped connections
                        val fail = java.util.concurrent.atomic.AtomicReference<Exception?>(null)
                        val ws = (0 until parts).map { pi ->
                            thread {
                                try {
                                    val off = pi * chunk; val len = minOf(chunk, size - off)
                                    var fails = 0
                                    while (got[pi] < len && fail.get() == null) {
                                        try {
                                            open(host, port, "/f/$i?o=${off + got[pi]}&n=${len - got[pi]}&t=$t").use { sk ->
                                                val din = DataInputStream(sk.getInputStream())
                                                // network and storage work at the same time: this thread only reads the socket,
                                                // a writer thread saves to disk, so a slow flash write no longer stalls the Wi-Fi link
                                                val freeQ = java.util.concurrent.ArrayBlockingQueue<ByteArray>(3).also { fq -> repeat(3) { fq.add(ByteArray(1 shl 20)) } }
                                                val fullQ = java.util.concurrent.ArrayBlockingQueue<Pair<ByteArray, Int>>(4)
                                                val wErr = java.util.concurrent.atomic.AtomicReference<Exception?>(null)
                                                val writer = thread {
                                                    try {
                                                        while (true) {
                                                            val tw = System.nanoTime(); val (wb, wk) = fullQ.take(); wIdle.addAndGet(System.nanoTime() - tw)
                                                            if (wk < 0) break
                                                            ch.write(ByteBuffer.wrap(wb, 0, wk), off + got[pi]); got[pi] = got[pi] + wk.toLong(); fails = 0
                                                            add(wk)
                                                            freeQ.put(wb)
                                                        }
                                                    } catch (e: Exception) {
                                                        wErr.set(e)
                                                        try { while (true) { val (wb, wk) = fullQ.take(); if (wk < 0) break; freeQ.put(wb) } } catch (x: Exception) {}
                                                    }
                                                }
                                                var rd = got[pi]
                                                try {
                                                    while (rd < len && fail.get() == null && wErr.get() == null) {
                                                        while (paused && !cancelled) Thread.sleep(150)
                                                        if (cancelled) throw Cancelled()
                                                        val tq = System.nanoTime(); val b = freeQ.poll(200, java.util.concurrent.TimeUnit.MILLISECONDS); qWait.addAndGet(System.nanoTime() - tq); if (b == null) continue
                                                        val k = minOf(len - rd, b.size.toLong()).toInt()
                                                        try { din.readFully(b, 0, k) } catch (e: Exception) { freeQ.offer(b); throw e }
                                                        rd += k; fullQ.put(Pair(b, k))
                                                    }
                                                } finally {
                                                    fullQ.put(Pair(ByteArray(0), -1)); writer.join()
                                                }
                                                wErr.get()?.let { throw it }
                                            }
                                        } catch (e: Cancelled) { throw e }
                                        catch (e: Exception) {
                                            if (cancelled) throw e
                                            if (!paused && ++fails > 40) throw e   // a long pause is not a failure
                                            Thread.sleep(if (fails <= 2) 300L else 1500L)   // link dropped: wait, then continue from got[pi], not from zero
                                        }
                                    }
                                } catch (e: Exception) { fail.set(e) }
                            }
                        }
                        ws.forEach { it.join() }
                        val f0 = fail.get()
                        if (f0 != null) {
                            if (cancelled || f0 is Cancelled) throw f0
                            // some connections kept failing: finish ONLY the missing parts on one connection (nothing is downloaded twice)
                            status("Link is unstable, finishing with a single connection...")
                            for (pi in 0 until parts) {
                                val off = pi * chunk; val len = minOf(chunk, size - off)
                                var tries = 0
                                while (got[pi] < len) {
                                    try {
                                        open(host, port, "/f/$i?o=${off + got[pi]}&n=${len - got[pi]}&t=$t").use { sk ->
                                            val din = DataInputStream(sk.getInputStream()); val buf = ByteArray(1 shl 20)
                                            while (got[pi] < len) {
                                                while (paused && !cancelled) Thread.sleep(150)
                                                if (cancelled) throw Cancelled()
                                                val k = minOf(len - got[pi], buf.size.toLong()).toInt()
                                                din.readFully(buf, 0, k)
                                                ch.write(ByteBuffer.wrap(buf, 0, k), off + got[pi]); got[pi] = got[pi] + k.toLong(); tries = 0
                                                add(k)
                                            }
                                        }
                                    } catch (e: Cancelled) { throw e }
                                    catch (e: Exception) { if (cancelled) throw e; if (!paused && ++tries > 40) throw e; Thread.sleep(1000) }
                                }
                            }
                        }
                    }
                } catch (e: Exception) { throw e }
                contentResolver.update(u, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
                pend.remove(u)
            }

            // small files: 8 at a time (saves the per-file setup time); big files: one by one, each with parallel parts
            val small = (0 until n).filter { list.getJSONObject(it).getLong("s") <= (8L shl 20) }
            val big = (0 until n).filter { list.getJSONObject(it).getLong("s") > (8L shl 20) }
            if (small.isNotEmpty()) {
                val q = java.util.concurrent.ConcurrentLinkedQueue<Int>(small)
                val sfail = java.util.concurrent.atomic.AtomicReference<Exception?>(null)
                val sw = (0 until minOf(8, small.size)).map {
                    thread {
                        try { while (sfail.get() == null) { val i = q.poll() ?: break; one(i) } }
                        catch (e: Exception) { sfail.compareAndSet(null, e) }
                    }
                }
                sw.forEach { it.join() }
                sfail.get()?.let { throw it }
            }
            for (i in big) one(i)

            try { val fk = open(host, port, "/ping?t=$t&rp=0&d=$total&sp=" + String.format(java.util.Locale.US, "%.2f", spE)); fk.getInputStream().read(); fk.close(); socks.remove(fk) } catch (e: Exception) {}   // tell the sender: all bytes are saved
            val secs = maxOf(0.1, (System.currentTimeMillis() - start) / 1000.0)
            val names = JSONArray(); nameArr.forEach { names.put(it) }
            val uris = JSONArray(); uriArr.forEach { uris.put(it) }
            emit(JSONObject().put("t", "pdone").put("size", total).put("names", names).put("uris", uris).put("avg", total / 1048576.0 / secs).put("limit", limitText(qWait.get(), wIdle.get())))
        } catch (e: Exception) {
            pend.forEach { try { contentResolver.delete(it, null, null) } catch (x: Exception) {} }   // cancelled or failed: remove incomplete files
            if (e is Cancelled || cancelled) { if (e is Cancelled && !cancelled) cancelBy = "peer"; cancelUi(cancelBy) }
            else err("Transfer failed: " + e.javaClass.simpleName + " " + (e.message ?: "") + ". Both phones must be on the same Wi-Fi or hotspot.")
        } finally { alive.set(false); wifi(false) }
    }

    // ---------- Fast mode: direct Wi-Fi link between the phones (no router needed) ----------
    private var hotspot: WifiManager.LocalOnlyHotspotReservation? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { startHotspot() }
    private fun fastPerms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.NEARBY_WIFI_DEVICES)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    private fun ensureServer() {
        if (srv == null) {
            tok = java.lang.Long.toHexString(java.util.Random().nextLong() and 0xffffffffL)
            srv = ServerSocket(0, 50); serve(); svc(true)
        }
    }
    private fun hotIp(): String {
        var dot1 = ""
        for (n in (NetworkInterface.getNetworkInterfaces()?.toList() ?: emptyList<NetworkInterface>())) for (a in n.inetAddresses) {
            if (a !is Inet4Address || a.isLoopbackAddress || !a.isSiteLocalAddress) continue
            val nm = n.name.lowercase()
            if (nm.startsWith("ap") || nm.startsWith("swlan") || nm.startsWith("softap") || nm.startsWith("p2p")) return a.hostAddress ?: ""
            if (a.address[3] == 1.toByte()) dot1 = a.hostAddress ?: ""
        }
        return dot1
    }
    // Wi-Fi Direct is warmed up WHILE the camera is open, so the link forms right after the QR is read
    @Volatile private var preMgr: android.net.wifi.p2p.WifiP2pManager? = null
    @Volatile private var preCh: android.net.wifi.p2p.WifiP2pManager.Channel? = null
    @Volatile private var preAt = 0L
    @Volatile private var scanAt = 0L
    private fun took(): String = if (scanAt > 0) String.format(java.util.Locale.US, " · connected in %.1fs", (System.currentTimeMillis() - scanAt) / 1000.0) else ""
    @Suppress("MissingPermission")
    private fun prewarmP2p() {
        if (p2pMgr != null || hotspot != null || preMgr != null) return
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) return
        thread {
            try {
                if (!(applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled) return@thread
                val m = getSystemService(Context.WIFI_P2P_SERVICE) as android.net.wifi.p2p.WifiP2pManager
                val ch = m.initialize(this, Looper.getMainLooper(), null)
                val l = java.util.concurrent.CountDownLatch(1)
                m.removeGroup(ch, latchListener(l)); l.await(1500, java.util.concurrent.TimeUnit.MILLISECONDS)   // clear any old group
                m.discoverPeers(ch, null)
                preMgr = m; preCh = ch; preAt = System.currentTimeMillis()
            } catch (e: Exception) {}
        }
    }
    @Suppress("MissingPermission")
    private fun dropPrewarm() {
        try { val m = preMgr; val c = preCh; if (m != null && c != null) m.stopPeerDiscovery(c, null) } catch (e: Exception) {}
        preMgr = null; preCh = null
    }
    private var p2pMgr: android.net.wifi.p2p.WifiP2pManager? = null
    private var p2pCh: android.net.wifi.p2p.WifiP2pManager.Channel? = null
    @Volatile private var useLoh = false
    @Volatile private var p2pLabel = ""
    @Volatile private var p2pFreq = 0          // MHz of the Wi-Fi Direct group we host/joined (0 = none)
    @Volatile private var forceScc = false     // set after repeated group drops: stay on the router's channel even if it is 2.4 GHz
    @Volatile private var dropCount = 0
    // frequency (MHz) of the normal Wi-Fi network (router) this phone is connected to, 0 if none
    @Suppress("DEPRECATION")
    private fun staFreq(): Int = try {
        val wi = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).connectionInfo
        if (wi != null && wi.networkId != -1 && wi.frequency > 0) wi.frequency else 0
    } catch (e: Exception) { 0 }
    private fun isDfs(f: Int) = f in 5251..5729          // radar channels: a group owner often cannot start there
    // Frequency to create the group on so that the router link and the direct link share ONE channel (no time-slicing between channels).
    // 0 = no router / not a usable channel: keep the normal "5 GHz band" behaviour.
    private fun sccFreq(): Int {
        val f = staFreq()
        if (f <= 0 || f >= 5900) return 0
        return if (f in 5170..5835 && !isDfs(f)) f else if (forceScc) f else 0
    }
    private fun chan(f: Int) = if (f == 2484) 14 else if (f in 2412..2472) (f - 2407) / 5 else if (f in 5000..5900) (f - 5000) / 5 else 0
    private fun chanInfo(f: Int): String {
        if (f <= 0) return ""
        val sf = staFreq()
        val rel = if (sf <= 0) " · no router" else if (sf == f) " · same channel as router" else " · router on ch " + chan(sf)
        return " · ch " + chan(f) + " (" + f + " MHz)" + rel
    }
    // which network interface carries the traffic to the peer (proof that the direct link, not the router, is used)
    private fun viaIface(peer: String): String = try {
        if (peer.isEmpty()) "" else {
            val pre = peer.substringBeforeLast('.') + "."
            var nm = ""
            for (n in (NetworkInterface.getNetworkInterfaces()?.toList() ?: emptyList<NetworkInterface>()))
                if (n.inetAddresses.toList().any { it is Inet4Address && (it.hostAddress ?: "").startsWith(pre) }) nm = n.name
            if (nm.isEmpty()) " · WARNING: peer is not on a local interface" else " · via $nm"
        }
    } catch (e: Exception) { "" }
    private fun stopHotspot() {
        try { hotspot?.close() } catch (e: Exception) {}; hotspot = null
        try { val m = p2pMgr; val c = p2pCh; if (m != null && c != null) { m.cancelConnect(c, null); m.removeGroup(c, null) } } catch (e: Exception) {}
        p2pMgr = null; p2pCh = null; p2pLabel = ""; p2pFreq = 0
    }
    private fun ensureWifiOn(secs: Int = 40): Boolean {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        if (wm.isWifiEnabled) return true
        status("Turn the Wi-Fi switch ON. No Wi-Fi network or router is needed, only the switch.")
        runOnUiThread {
            try { startActivity(Intent(android.provider.Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) }
            catch (e: Exception) { try { startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)) } catch (e2: Exception) {} }
        }
        emit(JSONObject().put("t", "needwifi"))
        val end = System.currentTimeMillis() + secs * 1000L
        while (!wm.isWifiEnabled && System.currentTimeMillis() < end) Thread.sleep(500)
        if (wm.isWifiEnabled) Thread.sleep(1500)
        return wm.isWifiEnabled
    }
    private fun latchListener(l: java.util.concurrent.CountDownLatch) = object : android.net.wifi.p2p.WifiP2pManager.ActionListener {
        override fun onSuccess() { l.countDown() }
        override fun onFailure(reason: Int) { l.countDown() }
    }
    // InShare-style Fast mode: a Wi-Fi Direct group pinned to 5 GHz. Cleans old state first, retries when Android is busy,
    // and re-creates the group by itself if Android drops it while waiting for the other phone.
    @Suppress("MissingPermission")
    private fun startP2pGroup(band: Int, label: String, fallback: () -> Unit) {
        val pr = try {
            val mm = getSystemService(Context.WIFI_P2P_SERVICE) as android.net.wifi.p2p.WifiP2pManager
            Pair(mm, mm.initialize(this, Looper.getMainLooper(), null))
        } catch (e: Exception) { stopHotspot(); fallback(); return }
        val m = pr.first; val ch = pr.second
        p2pMgr = m; p2pCh = ch
        val done = java.util.concurrent.atomic.AtomicBoolean(false)
        fun fail() { if (done.compareAndSet(false, true)) { stopHotspot(); Handler(Looper.getMainLooper()).post { fallback() } } }
        Handler(Looper.getMainLooper()).postDelayed({ if (!done.get()) fail() }, 35000)
        thread {
            try {
                wifi(false)   // low-latency lock off while the group is created (ensureServer() takes it again afterwards)
                val rnd = java.util.Random()
                val chars = "abcdefghjkmnpqrstuvwxyz23456789"
                fun rs(n: Int) = (1..n).map { chars[rnd.nextInt(chars.length)] }.joinToString("")
                val pre = "DIRECT-" + (if (band == android.net.wifi.p2p.WifiP2pConfig.GROUP_OWNER_BAND_5GHZ) "50" else "24") + "-"
                val keep = hostSsid.startsWith(pre) && hostPass.isNotEmpty()
                val ssid = if (keep) hostSsid else pre + rs(8); val pass = if (keep) hostPass else rs(8)
                hostSsid = ssid; hostPass = pass
                var curFreq = sccFreq()   // >0: create the group on the router's own channel
                fun mk(): android.net.wifi.p2p.WifiP2pConfig {
                    val b = android.net.wifi.p2p.WifiP2pConfig.Builder().setNetworkName(ssid).setPassphrase(pass).enablePersistentMode(false)
                    if (curFreq > 0) { try { b.setGroupOperatingFrequency(curFreq) } catch (e: Exception) { curFreq = 0; b.setGroupOperatingBand(band) } }
                    else b.setGroupOperatingBand(band)
                    return b.build()
                }
                fun clearGroup() {
                    m.cancelConnect(ch, null)
                    val l = java.util.concurrent.CountDownLatch(1)
                    m.removeGroup(ch, latchListener(l)); l.await(2, java.util.concurrent.TimeUnit.SECONDS)
                    val end = System.currentTimeMillis() + 3000
                    while (System.currentTimeMillis() < end) {   // wait until Android really has no old group left
                        val g = java.util.concurrent.CountDownLatch(1); var has = false
                        m.requestGroupInfo(ch) { x -> has = x != null; g.countDown() }
                        g.await(1, java.util.concurrent.TimeUnit.SECONDS)
                        if (!has) break
                        Thread.sleep(300)
                    }
                }
                clearGroup(); Thread.sleep(400)
                var created = false
                for (i in 0..((if (band == android.net.wifi.p2p.WifiP2pConfig.GROUP_OWNER_BAND_5GHZ) 1 else 2) + (if (curFreq > 0) 1 else 0))) {
                    if (done.get()) return@thread
                    val l = java.util.concurrent.CountDownLatch(1); var ok = false; var code = -1
                    m.createGroup(ch, mk(), object : android.net.wifi.p2p.WifiP2pManager.ActionListener {
                        override fun onSuccess() { ok = true; l.countDown() }
                        override fun onFailure(reason: Int) { code = reason; l.countDown() }
                    })
                    l.await(if (band == android.net.wifi.p2p.WifiP2pConfig.GROUP_OWNER_BAND_5GHZ) 7L else 10L, java.util.concurrent.TimeUnit.SECONDS)
                    if (ok) { created = true; break }
                    if (curFreq > 0) { curFreq = 0; clearGroup(); continue }   // the router's channel was refused: use the normal band instead
                    if (code == 1 || code == 3) break          // not supported on this phone / band: no point retrying
                    Thread.sleep(600); clearGroup()            // busy: clean and try again
                }
                if (!created) { fail(); return@thread }
                var h = ""
                repeat(80) { if (h.isEmpty()) { h = hotIp(); if (h.isEmpty()) Thread.sleep(150) } }
                if (h.isEmpty()) { fail(); return@thread }
                if (!done.compareAndSet(false, true)) return@thread
                var gf = 0
                try { val gq = java.util.concurrent.CountDownLatch(1); m.requestGroupInfo(ch) { g -> gf = g?.frequency ?: 0; gq.countDown() }; gq.await(2, java.util.concurrent.TimeUnit.SECONDS) } catch (e: Exception) {}
                p2pFreq = gf
                p2pLabel = label + chanInfo(gf)
                if (band == android.net.wifi.p2p.WifiP2pConfig.GROUP_OWNER_BAND_5GHZ) getSharedPreferences("ft", Context.MODE_PRIVATE).edit().putInt("fail5", 0).apply()
                ensureServer()
                var go = ""
                try {
                    val gl = java.util.concurrent.CountDownLatch(1)
                    m.requestGroupInfo(ch) { g -> go = g?.owner?.deviceAddress ?: ""; gl.countDown() }
                    gl.await(2, java.util.concurrent.TimeUnit.SECONDS)
                } catch (e: Exception) {}
                fun b64(x: String) = android.util.Base64.encodeToString(x.toByteArray(), android.util.Base64.NO_WRAP or android.util.Base64.URL_SAFE)
                // field 8 = normal Wi-Fi address (safe fallback), field 9 = group owner address
                emit(JSONObject().put("t", "qr").put("qr", (if (hostAsSender) "FT5" else "FT4") + "|$h|${srv!!.localPort}|$tok|${b64(ssid)}|${b64(pass)}|1|${ip().let { if (it == h) "" else it }}|$go"))
                // watchdog: some phones silently drop an idle group - bring it back (new QR appears by itself)
                var miss = 0
                while (p2pMgr === m) {
                    Thread.sleep(3000)
                    if (p2pMgr !== m) break
                    val g = java.util.concurrent.CountDownLatch(1); var has = true
                    m.requestGroupInfo(ch) { x -> has = x != null; g.countDown() }
                    g.await(2, java.util.concurrent.TimeUnit.SECONDS)
                    if (has) miss = 0
                    else if (++miss >= 2) { dropCount++; if (dropCount >= 2) forceScc = true; stopHotspot(); Handler(Looper.getMainLooper()).post { startHotspot(0) }; break }   // silent restart, same QR
                }
            } catch (e: Exception) { fail() }
        }
    }
    // joiner side: join the other phone's Wi-Fi Direct group by name+password (no popup). Resets Android's old P2P state first
    // and tries twice (exact address, then wildcard) before giving up.
    @Suppress("MissingPermission")
    private fun p2pJoin(port: Int, rt: String, ssid: String, pass: String, goAddr: String, fallback: (String) -> Unit) {
        try {
            val warm = preMgr != null && System.currentTimeMillis() - preAt < 90000
            val m = preMgr ?: (getSystemService(Context.WIFI_P2P_SERVICE) as android.net.wifi.p2p.WifiP2pManager)
            val ch = preCh ?: m.initialize(this, Looper.getMainLooper(), null)
            preMgr = null; preCh = null
            p2pMgr = m; p2pCh = ch
            wifi(false)   // the low-latency Wi-Fi lock (taken when the Send screen opens) blocks Wi-Fi Direct discovery: let go while joining
            var why = ""
            fun reset() {
                m.cancelConnect(ch, null)
                // only wait for removeGroup when Android really has an old group (saves ~2 s on a clean phone)
                val gi = java.util.concurrent.CountDownLatch(1); var has = false
                m.requestGroupInfo(ch) { x -> has = x != null; gi.countDown() }
                gi.await(600, java.util.concurrent.TimeUnit.MILLISECONDS)
                if (has) {
                    val l = java.util.concurrent.CountDownLatch(1)
                    m.removeGroup(ch, latchListener(l)); l.await(2, java.util.concurrent.TimeUnit.SECONDS)
                    Thread.sleep(300)
                }
            }
            fun attempt(addr: String, secs: Int): String? {
                try {
                    val cfg = android.net.wifi.p2p.WifiP2pConfig.Builder()
                        .setDeviceAddress(android.net.MacAddress.fromString(addr))
                        .setNetworkName(ssid).setPassphrase(pass).build()
                    val latch = java.util.concurrent.CountDownLatch(1); val ok = java.util.concurrent.atomic.AtomicBoolean(false)
                    var code = -1
                    m.connect(ch, cfg, object : android.net.wifi.p2p.WifiP2pManager.ActionListener {
                        override fun onSuccess() { ok.set(true); latch.countDown() }
                        override fun onFailure(reason: Int) { code = reason; latch.countDown() }
                    })
                    latch.await(8, java.util.concurrent.TimeUnit.SECONDS)
                    if (!ok.get()) { why = "Android refused, code $code"; return null }
                    var host: String? = null
                    val end = System.currentTimeMillis() + secs * 1000L
                    while (host == null && System.currentTimeMillis() < end && !cancelled) {
                        val got = java.util.concurrent.CountDownLatch(1)
                        m.requestConnectionInfo(ch) { info -> if (info != null && info.groupFormed && !info.isGroupOwner) host = info.groupOwnerAddress?.hostAddress; got.countDown() }
                        got.await(1, java.util.concurrent.TimeUnit.SECONDS)
                        if (host == null) Thread.sleep(80)
                    }
                    if (host == null) why = "link did not form"
                    return host
                } catch (e: Exception) { why = e.javaClass.simpleName; return null }
            }
            var h: String? = null
            for (round in 1..3) {
                if (cancelled) break
                status(if (round == 1) "Connecting (Wi-Fi Direct)..." else "Retrying Wi-Fi Direct ($round/3)...")
                if (round == 1 && warm) m.discoverPeers(ch, null)   // already clean: just kick discovery again, no waiting
                else { reset(); m.discoverPeers(ch, null); Thread.sleep(700) }
                if (goAddr.isNotEmpty()) { h = attempt(goAddr, if (round == 1) 7 else if (round == 2) 9 else 14); if (h != null) break; reset() }
                h = attempt("02:00:00:00:00:00", if (round == 1) 5 else if (round == 2) 8 else 12)
                if (h != null) break
            }
            if (h == null) { stopHotspot(); fallback(why); return }
            var gf = 0
            try { val gq = java.util.concurrent.CountDownLatch(1); m.requestGroupInfo(ch) { g -> gf = g?.frequency ?: 0; gq.countDown() }; gq.await(1, java.util.concurrent.TimeUnit.SECONDS) } catch (e: Exception) {}
            p2pFreq = gf
            direct = true; p2pLabel = "Wi-Fi Direct" + (if (gf > 0) (if (gf >= 4900) " 5 GHz" else " 2.4 GHz") + chanInfo(gf) else "")
            link(h, port, rt)
        } catch (e: Exception) { wifi(true); stopHotspot(); fallback(e.javaClass.simpleName) }
    }
    private fun unbind() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            netCb?.let { cm.unregisterNetworkCallback(it) }; netCb = null
            cm.bindProcessToNetwork(null)
        } catch (e: Exception) {}
        try {   // leave the receiver's temporary Wi-Fi and go back to the normal one
            if (legacyId >= 0) {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION") wm.removeNetwork(legacyId); legacyId = -1; wm.reconnect()
            }
        } catch (e: Exception) {}
    }
    private var wantHotspot = false
    override fun onResume() {
        super.onResume()
        emit(JSONObject().put("t", "perm"))
        if (wantHotspot) {
            val lm = getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
            if (lm.isLocationEnabled) { wantHotspot = false; startHotspot() }
        }
    }
    private fun startHotspot(attempt: Int = 0) {
        val skipP2p = useLoh; useLoh = false
        if (Build.VERSION.SDK_INT < 33) {   // Android 12 and older cannot start a hotspot while Location is switched off
            val lm = getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
            if (!lm.isLocationEnabled) {
                wantHotspot = true
                emit(JSONObject().put("t", "needloc"))
                try { startActivity(Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS)) } catch (e: Exception) {}
                return
            }
        }
        val wifiOn = try { (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled } catch (e: Exception) { true }
        if (attempt == 0 && !skipP2p && !wifiOn) {
            thread {
                if (ensureWifiOn(25)) runOnUiThread { startHotspot(0) }
                else {
                    status("Wi-Fi is still off - starting a hotspot instead (a bit slower, no network needed)")
                    useLoh = true
                    runOnUiThread { startHotspot(0) }
                }
            }
            return
        }
        if (attempt == 0 && !skipP2p && wifiOn) {
            val sp = getSharedPreferences("ft", Context.MODE_PRIVATE)
            val auto = { startP2pGroup(android.net.wifi.p2p.WifiP2pConfig.GROUP_OWNER_BAND_AUTO, "Wi-Fi Direct") { useLoh = true; startHotspot(0) } }
            // this phone failed the 5 GHz try twice in the last day: go straight to the automatic band (saves ~10 s)
            if (sp.getInt("fail5", 0) >= 2 && System.currentTimeMillis() - sp.getLong("fail5At", 0L) < 24L * 3600 * 1000) auto()
            else startP2pGroup(android.net.wifi.p2p.WifiP2pConfig.GROUP_OWNER_BAND_5GHZ, "Wi-Fi Direct 5 GHz") {
                sp.edit().putInt("fail5", sp.getInt("fail5", 0) + 1).putLong("fail5At", System.currentTimeMillis()).apply()
                auto()
            }
            return
        }
        stopHotspot()
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(reservation: WifiManager.LocalOnlyHotspotReservation?) {
                    val r = reservation ?: return
                    hotspot = r
                    var ssid = ""; var pass = ""
                    if (Build.VERSION.SDK_INT >= 30) { val c = r.softApConfiguration; ssid = c.ssid ?: ""; pass = c.passphrase ?: "" }
                    else { @Suppress("DEPRECATION") val c = r.wifiConfiguration; ssid = c?.SSID ?: ""; pass = c?.preSharedKey ?: "" }
                    ssid = ssid.trim('"'); pass = pass.trim('"')
                    thread {
                        var h = ""
                        repeat(20) { if (h.isEmpty()) { h = hotIp(); if (h.isEmpty()) Thread.sleep(400) } }
                        if (h.isEmpty()) { stopHotspot(); err("Fast mode: the hotspot started but has no address yet. Please try again."); return@thread }
                        ensureServer()
                        val sec = if (Build.VERSION.SDK_INT >= 30) r.softApConfiguration.securityType else 1
                        fun b64(x: String) = android.util.Base64.encodeToString(x.toByteArray(), android.util.Base64.NO_WRAP or android.util.Base64.URL_SAFE)
                        emit(JSONObject().put("t", "qr").put("qr", (if (hostAsSender) "FT5" else "FT4") + "|$h|${srv!!.localPort}|$tok|${b64(ssid)}|${b64(pass)}|$sec|${ip().let { if (it == h) "" else it }}"))
                    }
                }
                override fun onFailed(reason: Int) {
                    if (attempt == 0) Handler(Looper.getMainLooper()).postDelayed({ startHotspot(1) }, 1200)   // first start often fails: retry once by itself
                    else err("Fast mode could not start (code $reason). Turn on Location, turn off any hotspot, then try again.")
                }
                override fun onStopped() {}
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) { err("Fast mode failed: " + e.javaClass.simpleName + " " + (e.message ?: "")) }
    }
    // sender side: join the receiver's direct Wi-Fi, then introduce ourselves
    private fun specJoin(ip0: String, port: Int, rt: String, ssid: String, pass: String, sec: Int = 1, ipN: String = "", attempt: Int = 0) {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val sb = WifiNetworkSpecifier.Builder().setSsid(ssid)
            if (sec == 3) sb.setWpa3Passphrase(pass) else sb.setWpa2Passphrase(pass)
            if (attempt == 1) sb.setIsHiddenSsid(true)   // 2nd try: directed probe, connects even if the scan list misses the hotspot
            val spec = sb.build()
            val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).setNetworkSpecifier(spec).build()
            netCb?.let { try { cm.unregisterNetworkCallback(it) } catch (e: Exception) {} }
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    cm.bindProcessToNetwork(network)
                    thread {
                        var gw: String? = null
                        repeat(12) {
                            if (gw == null) {
                                gw = cm.getLinkProperties(network)?.routes
                                    ?.firstOrNull { it.hasGateway() && it.gateway is Inet4Address }?.gateway?.hostAddress
                                if (gw == null) Thread.sleep(250)
                            }
                        }
                        direct = true
                        link(gw ?: ip0, port, rt)
                    }
                }
                override fun onUnavailable() {
                thread {
                    val near = nearbySsids()
                    // the QR name may differ from what the receiver really broadcasts: try the visible AndroidShare_ network
                    val alt = near.firstOrNull { it.startsWith("AndroidShare_") && it != ssid }
                    if (attempt == 0 && alt != null) { status("Found " + alt + ", trying it..."); specJoin(ip0, port, rt, alt, pass, sec, ipN, 1); return@thread }
                    if (attempt == 0 && ipN.isEmpty()) { status("Retrying direct Wi-Fi..."); specJoin(ip0, port, rt, ssid, pass, sec, ipN, 1); return@thread }
                    if (ipN.isNotEmpty()) { status("Trying the normal Wi-Fi route..."); link(ipN, port, rt); return@thread }
                    manualJoin(ip0, port, rt, ssid, pass)
                }
            }
            }
            netCb = cb
            cm.requestNetwork(req, cb, if (attempt == 0) 15000 else 10000)
        } catch (e: Exception) { err("Fast mode failed: " + e.javaClass.simpleName + " " + (e.message ?: "")) }
    }

    // installs a received .apks bundle (base + split APKs) straight from this app, no extra installer app needed
    private fun installBundle(u: Uri) {
        try {
            if (!packageManager.canRequestPackageInstalls()) {
                runOnUiThread { try { startActivity(Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))) } catch (e: Exception) {} }
                err("Allow \"Install unknown apps\" for File Transfer, then tap Install again.")
                return
            }
            val pi = packageManager.packageInstaller
            val sid = pi.createSession(android.content.pm.PackageInstaller.SessionParams(android.content.pm.PackageInstaller.SessionParams.MODE_FULL_INSTALL))
            val session = pi.openSession(sid)
            var n = 0
            try {
                contentResolver.openInputStream(u)!!.use { raw ->
                    java.util.zip.ZipInputStream(raw).use { z ->
                        while (true) {
                            val e = z.nextEntry ?: break
                            if (e.isDirectory || !e.name.endsWith(".apk", true)) continue
                            session.openWrite("p" + n + ".apk", 0, -1).use { out -> z.copyTo(out, 1 shl 20); session.fsync(out) }
                            n++
                        }
                    }
                }
            } catch (e: Exception) { session.abandon(); throw e }
            if (n == 0) { session.abandon(); err("This bundle has no APK inside."); return }
            val act = "com.saad.filetransfer.INSTALL_DONE." + sid
            val rcv = object : android.content.BroadcastReceiver() {
                override fun onReceive(c: Context?, i: Intent?) {
                    if (i == null) return
                    val st = i.getIntExtra(android.content.pm.PackageInstaller.EXTRA_STATUS, -1)
                    if (st == android.content.pm.PackageInstaller.STATUS_PENDING_USER_ACTION) {
                        @Suppress("DEPRECATION") val ask = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                        try { if (ask != null) { ask.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(ask) } } catch (e: Exception) {}
                        return
                    }
                    try { unregisterReceiver(this) } catch (e: Exception) {}
                    val m = i.getStringExtra(android.content.pm.PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""
                    if (st == android.content.pm.PackageInstaller.STATUS_SUCCESS) emit(JSONObject().put("t", "toast").put("msg", "Installed"))
                    else if (st == android.content.pm.PackageInstaller.STATUS_FAILURE_ABORTED) emit(JSONObject().put("t", "toast").put("msg", "Install cancelled"))
                    else err(if (m.contains("OLDER_SDK")) "This app needs a newer Android version than this phone has, so it cannot be installed here. ($m)" else "Install failed: $m")
                }
            }
            val f = android.content.IntentFilter(act)
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(rcv, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(rcv, f)
            val pend = android.app.PendingIntent.getBroadcast(this, sid, Intent(act).setPackage(packageName), android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_MUTABLE)
            status("Installing...")
            session.use { it.commit(pend.intentSender) }
        } catch (e: Exception) { err("Could not install: " + e.javaClass.simpleName + " " + (e.message ?: "")) }
    }
    private fun icon(d: android.graphics.drawable.Drawable): String {
        val sz = 64
        val bm = android.graphics.Bitmap.createBitmap(sz, sz, android.graphics.Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, sz, sz); d.draw(android.graphics.Canvas(bm))
        val bo = java.io.ByteArrayOutputStream(); bm.compress(android.graphics.Bitmap.CompressFormat.PNG, 90, bo)
        return android.util.Base64.encodeToString(bo.toByteArray(), android.util.Base64.NO_WRAP)
    }

    // split apps: pack base + all split APKs into ONE .apks file so nothing is missing
    private fun bundle(ai: android.content.pm.ApplicationInfo, label: String): File {
        val out = File(cacheDir, "$label.apks")
        ZipOutputStream(BufferedOutputStream(FileOutputStream(out), 1 shl 20)).use { z ->
            z.setLevel(0)
            (listOf(ai.sourceDir) + (ai.splitSourceDirs ?: emptyArray<String>())).forEach { p ->
                val f = File(p); z.putNextEntry(ZipEntry(f.name))
                f.inputStream().use { it.copyTo(z, 1 shl 20) }; z.closeEntry()
            }
        }
        return out
    }

    // ---------- Sender: join the receiver's direct Wi-Fi quickly (ShareMe-style), with step-by-step status ----------
    private var legacyId = -1
    @Volatile private var hostAsSender = false   // new fast mode: the SENDER makes the hotspot, the receiver scans its QR
    @Volatile private var pullMode = false       // receiver joined the sender's hotspot: download from it
    @Volatile private var direct = false   // true only when we really joined the receiver's own hotspot
    private fun status(m: String) = emit(JSONObject().put("t", "status").put("msg", m))
    @Suppress("DEPRECATION")
    private fun bindToSubnet(ip0: String) {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val pre = ip0.substringBeforeLast('.')
            for (n in cm.allNetworks) {
                val lp = cm.getLinkProperties(n) ?: continue
                if (lp.linkAddresses.any { (it.address.hostAddress ?: "").startsWith("$pre.") }) { cm.bindProcessToNetwork(n); return }
            }
        } catch (e: Exception) {}
    }
    // Silent join with the classic Wi-Fi API (works because the app targets an older Android level). No pop-up, usually under 2 seconds.
    @Suppress("DEPRECATION")
    private fun legacyJoin(ssid: String, pass: String, ip0: String): Boolean {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (!wm.isWifiEnabled) wm.isWifiEnabled = true
            val q = "\"" + ssid + "\""
            val conf = android.net.wifi.WifiConfiguration()
            conf.SSID = q; conf.preSharedKey = "\"" + pass + "\""
            conf.allowedKeyManagement.set(android.net.wifi.WifiConfiguration.KeyMgmt.WPA_PSK)
            wm.configuredNetworks?.filter { it.SSID == q }?.forEach { wm.removeNetwork(it.networkId) }
            val id = wm.addNetwork(conf)
            if (id < 0) return false
            legacyId = id
            wm.disconnect(); wm.enableNetwork(id, true); wm.reconnect()
            val end = System.currentTimeMillis() + 15000
            while (System.currentTimeMillis() < end) {
                val g = wm.dhcpInfo.gateway
                if (g != 0 && "${g and 255}.${(g shr 8) and 255}.${(g shr 16) and 255}.${(g shr 24) and 255}" == ip0) { bindToSubnet(ip0); return true }
                Thread.sleep(250)
            }
        } catch (e: Exception) {}
        return false
    }
    // Last resort that works on every phone: user picks the hotspot in Wi-Fi settings (password is copied), app continues by itself
    @Suppress("DEPRECATION")
    private fun onHotspotSubnet(ip0: String): Boolean = try {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val pre = ip0.substringBeforeLast('.') + "."
        cm.allNetworks.any { n -> cm.getLinkProperties(n)?.linkAddresses?.any { (it.address.hostAddress ?: "").startsWith(pre) } == true }
    } catch (e: Exception) { false }
    private fun manualJoin(ip0: String, port: Int, rt: String, ssid: String, pass: String) {
        try { (getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("pw", pass)) } catch (e: Exception) {}
        status("Tap \"" + ssid + "\" in Wi-Fi settings. Password (copied): " + pass + " - then come back, the app continues by itself.")
        runOnUiThread { try { startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)) } catch (e: Exception) {} }
        thread {
            val end = System.currentTimeMillis() + 120000
            while (System.currentTimeMillis() < end && !cancelled) {
                if (onHotspotSubnet(ip0)) { bindToSubnet(ip0); direct = true; link(ip0, port, rt); return@thread }
                Thread.sleep(1000)
            }
            err("Could not connect to \"" + ssid + "\". Password: " + pass)
        }
    }
    @Suppress("DEPRECATION")
    private fun nearbySsids(): List<String> = try {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wm.startScan(); Thread.sleep(1500)
        wm.scanResults.map { it.SSID ?: "" }.filter { it.isNotEmpty() }.distinct()
    } catch (e: Exception) { emptyList() }
    private fun joinAndLink(ip0: String, port: Int, rt: String, ssid: String, pass: String, sec: Int = 1, ipN: String = "", go: String = "") {
        thread {
            direct = false
            val wmx = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (!wmx.isWifiEnabled) ensureWifiOn()
            status("Connecting to the receiver...")
            val classic: () -> Unit = {
                if (ip0.isNotEmpty() && applicationInfo.targetSdkVersion < 29 && legacyJoin(ssid, pass, ip0)) {
                    status("Joined the direct Wi-Fi")
                    link(ip0, port, rt)
                } else {
                    status("Asking Android to join " + ssid + "... tap Connect if it asks")
                    specJoin(ip0, port, rt, ssid, pass, sec, ipN)
                }
            }
            val no5 = ssid.startsWith("DIRECT-50-") && !(try { wmx.is5GHzBandSupported() } catch (e: Exception) { true })
            if (no5 && ipN.isNotEmpty()) {
                status("This phone has no 5 GHz Wi-Fi - using the normal Wi-Fi route")
                link(ipN, port, rt)
            } else if (ssid.startsWith("DIRECT-") && !classicJoin) p2pJoin(port, rt, ssid, pass, go) { why ->
                if (ipN.isNotEmpty()) { status("Direct link failed ($why). Using the normal Wi-Fi route (slower)..."); link(ipN, port, rt) }
                else { status("Direct link failed ($why). Trying Android's Wi-Fi join..."); classic() }
            } else { dropPrewarm(); classic() }
        }
    }

    // ---------- iPhone / iPad: they open a link (QR) in Safari. No app, no Wi-Fi Direct. Separate from the normal transfer ----------
    private var ios: IosShare? = null
    private fun iosUrl(ip: String, port: Int, t: String) = "http://$ip:$port/?t=$t"
    private fun stopIos() {
        val s = ios ?: return
        s.stop(); ios = null
        stopHotspot()                         // also closes the hotspot made for the iPhone, if any
        if (srv == null) svc(false)
    }
    private fun startIos(send: Boolean) {
        stopIos()
        val t = java.lang.Long.toHexString(java.util.Random().nextLong() and 0xffffffffffL)
        val s = IosShare(t, send, { items.toList() },
            { it -> if (it.path != null) FileInputStream(it.path) else contentResolver.openInputStream(it.uri!!)!! },
            { name ->
                val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "application/octet-stream"
                val u = entry(name, mime); Pair(u, contentResolver.openOutputStream(u)!!)
            },
            { u -> contentResolver.update(u, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null); Unit },
            { u -> try { contentResolver.delete(u, null, null) } catch (e: Exception) {}; Unit },
            { paused }, { o -> emit(o) }, { txt, pct -> TransferService.update(applicationContext, txt, pct) })
        try { s.start() } catch (e: Exception) { err("Could not start sharing for iPhone: " + e.javaClass.simpleName); return }
        ios = s; cancelled = false; paused = false
        svc(true)
        val ip = try { ip() } catch (e: Exception) { "" }
        emit(JSONObject().put("t", "iosqr").put("url", if (ip.isEmpty()) "" else iosUrl(ip, s.port, s.token)).put("ip", ip).put("wifi", ""))
    }
    // no common Wi-Fi: this phone makes its own hotspot; the iPhone joins it with the first QR, opens the page with the second
    @Suppress("MissingPermission")
    private fun startIosHotspot() {
        if (Build.VERSION.SDK_INT < 33) {
            val lm = getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
            if (!lm.isLocationEnabled) {
                err("Turn Location ON, then tap \"Make a hotspot\" again.")
                try { startActivity(Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS)) } catch (e: Exception) {}
                return
            }
        }
        stopHotspot()
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(reservation: WifiManager.LocalOnlyHotspotReservation?) {
                    val r = reservation ?: return
                    hotspot = r
                    var ssid = ""; var pass = ""
                    if (Build.VERSION.SDK_INT >= 30) { val c = r.softApConfiguration; ssid = c.ssid ?: ""; pass = c.passphrase ?: "" }
                    else { @Suppress("DEPRECATION") val c = r.wifiConfiguration; ssid = c?.SSID ?: ""; pass = c?.preSharedKey ?: "" }
                    ssid = ssid.trim('"'); pass = pass.trim('"')
                    thread {
                        var h = ""
                        repeat(20) { if (h.isEmpty()) { h = hotIp(); if (h.isEmpty()) Thread.sleep(400) } }
                        val sv = ios
                        if (h.isEmpty() || sv == null) { stopHotspot(); err("The hotspot started but has no address yet. Please try again."); return@thread }
                        fun e(x: String) = x.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace(":", "\\:").replace("\"", "\\\"")
                        emit(JSONObject().put("t", "iosqr").put("url", iosUrl(h, sv.port, sv.token)).put("ip", h)
                            .put("wifi", "WIFI:T:WPA;S:" + e(ssid) + ";P:" + e(pass) + ";;"))
                    }
                }
                override fun onFailed(reason: Int) { err("Could not start the hotspot (code $reason). Turn on Location, turn off any other hotspot, then try again.") }
                override fun onStopped() {}
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) { err("Hotspot failed: " + e.javaClass.simpleName + " " + (e.message ?: "")) }
    }

    private fun limitText(q: Long, w: Long): String = when {
        q + w < 500_000_000L -> ""
        q > w * 3 / 2 -> "phone storage"
        w > q * 3 / 2 -> "Wi-Fi link"
        else -> "balanced"
    }
    @Volatile private var classicJoin = false   // join the other phone's hotspot like a normal Wi-Fi network instead of Wi-Fi Direct (for testing slow phones)
    inner class Bridge {
        @JavascriptInterface fun permState(): String {
            fun g(x: String) = checkSelfPermission(x) == PackageManager.PERMISSION_GRANTED
            val o = JSONObject().put("loc", g(Manifest.permission.ACCESS_FINE_LOCATION))
            o.put("cam", g(Manifest.permission.CAMERA))
            o.put("wifi", try { (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled } catch (e: Exception) { true })
            o.put("locsvc", if (Build.VERSION.SDK_INT < 33) { try { (getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager).isLocationEnabled } catch (e: Exception) { true } } else JSONObject.NULL)
            o.put("nearby", if (Build.VERSION.SDK_INT >= 33) g(Manifest.permission.NEARBY_WIFI_DEVICES) else JSONObject.NULL)
            o.put("notif", if (Build.VERSION.SDK_INT >= 33) g(Manifest.permission.POST_NOTIFICATIONS) else JSONObject.NULL)
            return o.toString()
        }
        @JavascriptInterface fun askPerm(w: String) {
            val x = when (w) { "loc" -> Manifest.permission.ACCESS_FINE_LOCATION; "cam" -> Manifest.permission.CAMERA; "nearby" -> if (Build.VERSION.SDK_INT >= 33) Manifest.permission.NEARBY_WIFI_DEVICES else return; else -> if (Build.VERSION.SDK_INT >= 33) Manifest.permission.POST_NOTIFICATIONS else return }
            lastAsked = x; runOnUiThread { oneLauncher.launch(x) }
        }
        @JavascriptInterface fun pick() { runOnUiThread { picker.launch(arrayOf("*/*")) } }
        @JavascriptInterface fun iosSend() { thread { if (items.isEmpty()) err("Add files first.") else startIos(true) } }
        @JavascriptInterface fun iosRecv() { thread { startIos(false) } }
        @JavascriptInterface fun iosHotspot() { runOnUiThread { withJoinPerms { startIosHotspot() } } }
        @JavascriptInterface fun iosStop() { stopIos() }
        @JavascriptInterface fun clear() { items.clear(); emitFiles() }
        @JavascriptInterface fun start(): String {
            ensureServer()
            val a = try { ip() } catch (e: Exception) { "" }
            return JSONObject().put("ip", a).put("port", srv!!.localPort).put("tok", tok).toString()
        }
        @JavascriptInterface fun fastSend() { forceScc = false; dropCount = 0; hostSsid = ""; hostPass = ""; cancelled = false; cancelSent.set(false); hostAsSender = true; runOnUiThread { permLauncher.launch(fastPerms()) } }
        @JavascriptInterface fun fastStop() { hostSsid = ""; hostPass = ""; hostAsSender = false; stopHotspot() }
        @JavascriptInterface fun fast(on: Boolean) { forceScc = false; dropCount = 0; hostSsid = ""; hostPass = ""; hostAsSender = false; if (!on) wantHotspot = false; runOnUiThread { if (on) permLauncher.launch(fastPerms()) else stopHotspot() } }
        // true when this phone is connected to a normal Wi-Fi network (a router): that limits the direct link's speed
        @JavascriptInterface fun wifiLinked(): Boolean = try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            @Suppress("DEPRECATION") cm.allNetworks.any { n ->
                val c = cm.getNetworkCapabilities(n)
                c != null && c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            }
        } catch (e: Exception) { false }
        // router link vs direct link: does the direct link share the router's channel (nothing to gain by disconnecting)?
        @JavascriptInterface fun routerInfo(): String = try {
            val f = staFreq()
            val band = if (f >= 5900) "6" else if (f >= 4900) "5" else if (f > 0) "2.4" else ""
            val scc = f > 0 && (if (p2pFreq > 0) p2pFreq == f else (f in 5170..5835 && !isDfs(f)))
            JSONObject().put("linked", wifiLinked()).put("band", band).put("scc", scc)
                .put("mismatch", f > 0 && p2pFreq > 0 && p2pFreq != f).put("gch", chan(p2pFreq)).put("rch", chan(f)).toString()
        } catch (e: Exception) { "{}" }
        @JavascriptInterface fun openWifi() { runOnUiThread {
            try { startActivity(Intent(android.provider.Settings.Panel.ACTION_WIFI)) }
            catch (e: Exception) { try { startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)) } catch (e2: Exception) {} } } }
        @JavascriptInterface fun openLoc() { runOnUiThread { try { startActivity(Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS)) } catch (e: Exception) {} } }
        @JavascriptInterface fun joinMode(m: String) { classicJoin = (m == "classic") }
        @JavascriptInterface fun wifiCaps(): String {
            return try {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                var std = "Wi-Fi 4 or older"
                if (Build.VERSION.SDK_INT >= 33 && wm.isWifiStandardSupported(8)) std = "Wi-Fi 7"
                else if (Build.VERSION.SDK_INT >= 30 && wm.isWifiStandardSupported(6)) std = "Wi-Fi 6"
                else if (Build.VERSION.SDK_INT >= 30 && wm.isWifiStandardSupported(5)) std = "Wi-Fi 5"
                std + (if (wm.is5GHzBandSupported()) ", 5 GHz" else ", 2.4 GHz only")
            } catch (e: Exception) { "" }
        }
        @JavascriptInterface fun apps() {
            thread {
                val pm = packageManager
                val ri = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                val seen = HashSet<String>(); val tmp = ArrayList<JSONObject>()
                for (r in ri) {
                    val ai = r.activityInfo.applicationInfo
                    if (!seen.add(ai.packageName)) continue
                    val sp = ai.splitSourceDirs
                    var size = File(ai.sourceDir).length(); sp?.forEach { size += File(it).length() }
                    tmp.add(JSONObject().put("p", ai.packageName).put("n", r.loadLabel(pm).toString())
                        .put("s", size).put("sp", sp?.size ?: 0).put("i", icon(r.loadIcon(pm))))
                }
                tmp.sortBy { it.getString("n").lowercase() }
                emit(JSONObject().put("t", "apps").put("list", JSONArray(tmp)))
            }
        }
        @JavascriptInterface fun addApps(json: String) {
            thread {
                val pm = packageManager; val arr = JSONArray(json)
                for (i in 0 until arr.length()) {
                    try {
                        val ai = pm.getApplicationInfo(arr.getString(i), 0)
                        val label = pm.getApplicationLabel(ai).toString().replace(Regex("[^A-Za-z0-9 _.-]"), "").trim().ifEmpty { ai.packageName }
                        if (ai.splitSourceDirs.isNullOrEmpty()) { val b = File(ai.sourceDir); items.add(Item(null, "$label.apk", b.length(), b.path)) }
                        else { val b = bundle(ai, label); items.add(Item(null, "$label.apks", b.length(), b.path)) }
                    } catch (e: Exception) { err("Could not add app: " + e.javaClass.simpleName + " " + (e.message ?: "")) }
                }
                emitFiles()
            }
        }
        @JavascriptInterface fun installApks(uri: String) { thread { installBundle(Uri.parse(uri)) } }
        @JavascriptInterface fun install(uri: String) {
            runOnUiThread {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(uri), "application/vnd.android.package-archive")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) { err("Open the file from Downloads > FileTransfer to install it.") }
            }
        }
        @JavascriptInterface fun pause(on: Boolean) { paused = on }
        @JavascriptInterface fun snapshot(): String = snap
        @JavascriptInterface fun minimize() { runOnUiThread { moveTaskToBack(true) } }
        @JavascriptInterface fun cancel() {
            ios?.cancelAll()
            cancelBy = "me"; cancelled = true; paused = false
            val h = peerHost; val pt = peerPort; val tk = peerTok
            thread {
                closeAll()           // stop our own transfer at once
                cancelUi("me")
                // tell the other phone (2 tries). If it cannot be reached, its heartbeat sees our 410 / closed port and cancels too
                for (i in 0..1) {
                    try {
                        if (h.isNotEmpty()) Socket().use { sk -> sk.connect(InetSocketAddress(h, pt), 2500); sk.getOutputStream().write("GET /bye?t=$tk HTTP/1.1\r\nHost: $h\r\nConnection: close\r\n\r\n".toByteArray()); sk.getOutputStream().flush(); sk.getInputStream().read() }
                        break
                    } catch (e: Exception) { }
                }
            }
        }
        @JavascriptInterface fun scan() {
            cancelled = false; cancelSent.set(false)
            wifi(false)   // the low-latency lock blocks Wi-Fi Direct discovery: release it BEFORE the camera warms Wi-Fi Direct up
            prewarmP2p()
            runOnUiThread {
                scanner.launch(Intent(this@MainActivity, ScanActivity::class.java))
            }
        }
        @JavascriptInterface fun stop() {
            try { srv?.close() } catch (e: Exception) {}
            srv = null; items.clear(); hostSsid = ""; hostPass = ""; wifi(false); stopHotspot(); unbind(); svc(false); cancelled = false; paused = false; snap = ""; cacheDir.listFiles()?.filter { it.name.endsWith(".apks") }?.forEach { it.delete() }
        }
    }
}
