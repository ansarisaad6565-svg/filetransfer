package com.saad.filetransfer

import android.content.ContentValues
import android.content.Intent
import android.content.Context
import android.Manifest
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataInputStream
import java.io.File
import java.io.BufferedOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread

class Cancelled : java.io.IOException("cancelled")

data class Item(val uri: Uri?, val name: String, val size: Long, val path: String? = null)

class MainActivity : ComponentActivity() {
    companion object {
        @Volatile var cur: WebView? = null
        @Volatile var snap: String = ""
        @Volatile var paused = false
        @Volatile var cancelled = false
        @Volatile var peerHost = ""
        @Volatile var peerPort = 0
        @Volatile var peerTok = ""
        val socks = java.util.concurrent.CopyOnWriteArrayList<Socket>()
    }
    private var wake: android.os.PowerManager.WakeLock? = null
    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private lateinit var wv: WebView
    private val items = java.util.concurrent.CopyOnWriteArrayList<Item>()
    private var srv: ServerSocket? = null
    private var tok = ""
    private val sent = AtomicLong(0)
    @Volatile private var t0 = 0L
    @Volatile private var last = 0L
    private var lock: WifiManager.WifiLock? = null
    private val BUF = 1 shl 20
    private val fin = AtomicBoolean(false)

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { us ->
        us.forEach { u ->
            contentResolver.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) items.add(Item(u,
                    c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)),
                    c.getLong(c.getColumnIndexOrThrow(OpenableColumns.SIZE))))
            }
        }
        emitFiles()
    }

    private val scanner = registerForActivityResult(ScanContract()) { r ->
        val txt = r.contents
        if (txt != null) {
            val p = txt.split("|")
            if (p.size == 4 && p[0] == "FT1") download(p[1], p[2].toIntOrNull() ?: 0, p[3])
            else if (p.size == 4 && p[0] == "FT2") link(p[1], p[2].toIntOrNull() ?: 0, p[3])
            else if (p.size >= 7 && p[0] == "FT4") joinAndLink(p[1], p[2].toIntOrNull() ?: 0, p[3],
                String(android.util.Base64.decode(p[4], android.util.Base64.URL_SAFE)), String(android.util.Base64.decode(p[5], android.util.Base64.URL_SAFE)), p[6].toIntOrNull() ?: 1, p.getOrElse(7) { "" })
            else if (p.size == 6 && p[0] == "FT3") joinAndLink(p[1], p[2].toIntOrNull() ?: 0, p[3], p[4], p[5])
            else err("That is not a File Transfer QR code.")
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        wv = WebView(this)
        cur = wv
        setContentView(wv)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.loadUrl("file:///android_asset/index.html")
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (snap.isNotEmpty()) moveTaskToBack(true) else wv.evaluateJavascript("goBack()") { if (it != "true") finish() } }
        })
    }

    override fun onDestroy() { if (cur === wv) cur = null; super.onDestroy() }
    private fun emit(o: JSONObject) {
        val t = o.optString("t")
        if (t == "s" || t == "p") snap = o.toString()
        else if (t == "sdone" || t == "pdone" || t == "err" || t == "cancelled") {
            snap = ""
            TransferService.update(applicationContext, if (t == "sdone" || t == "pdone") "Transfer complete" else "Transfer stopped", -1)
        }
        val w = cur ?: return
        w.post { w.evaluateJavascript("onNative($o)", null) }
    }
    private fun closeAll(keep: Socket? = null) {
        socks.forEach { if (it !== keep) try { it.close() } catch (e: Exception) {} }
        socks.removeAll { it.isClosed }
    }
    private fun svc(on: Boolean) {
        try {
            if (on) {
                startForegroundService(Intent(this, TransferService::class.java))
                if (wake == null) wake = (getSystemService(Context.POWER_SERVICE) as android.os.PowerManager)
                    .newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "ft:xfer").apply { setReferenceCounted(false) }
                wake?.acquire(4 * 3600 * 1000L)
            } else {
                stopService(Intent(this, TransferService::class.java))
                if (wake?.isHeld == true) wake?.release()
            }
        } catch (e: Exception) {}
    }
    private fun err(m: String) = emit(JSONObject().put("t", "err").put("msg", m))
    private fun emitFiles() {
        val a = JSONArray(); items.forEach { a.put(JSONObject().put("n", it.name).put("s", it.size)) }
        emit(JSONObject().put("t", "files").put("list", a))
    }
    private fun wifi(on: Boolean) {
        if (on) {
            if (lock == null) lock = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
                .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "ft").apply { setReferenceCounted(false) }
            lock?.acquire()
        } else if (lock?.isHeld == true) lock?.release()
    }
    private fun prog(t: String, name: String, i: Int, n: Int, done: Long, total: Long, start: Long) {
        val now = System.currentTimeMillis()
        if (now - last < 200 && done < total) return
        last = now
        val sp = done / 1048576.0 / maxOf(0.1, (now - start) / 1000.0)
        emit(JSONObject().put("t", t).put("name", name).put("i", i).put("n", n).put("done", done)
            .put("total", total).put("speed", sp).put("paused", paused).put("eta", if (sp > 0) (total - done) / 1048576.0 / sp else 0.0))
        TransferService.update(applicationContext, (if (t == "s") "Sending " else "Receiving ") + name + " - " + String.format("%.1f", sp) + " MB/s" + (if (paused) " (paused)" else ""),
            if (total > 0) (done * 100 / total).toInt() else 0)
    }
    private fun ip(): String {
        var best = ""
        for (n in NetworkInterface.getNetworkInterfaces()) for (a in n.inetAddresses)
            if (a is Inet4Address && !a.isLoopbackAddress && a.isSiteLocalAddress &&
                (best.isEmpty() || n.name.startsWith("wlan") || n.name.startsWith("ap"))) best = a.hostAddress ?: ""
        return best
    }

    // ---------- sender: raw-TCP HTTP server, 1 MB buffers ----------
    private fun serve() = thread(isDaemon = true) {
        val s = srv ?: return@thread
        while (!s.isClosed) {
            val c = try { s.accept() } catch (e: Exception) { break }
            socks.add(c); thread { try { handle(c) } catch (e: Exception) {} finally { try { c.close() } catch (e: Exception) {}; socks.remove(c) } }
        }
    }
    private fun handle(c: Socket) {
        c.sendBufferSize = 2 shl 20; c.tcpNoDelay = true
        val r = c.getInputStream().bufferedReader()
        val line = r.readLine() ?: return
        while (!r.readLine().isNullOrEmpty()) { }
        val p = line.split(" ").getOrNull(1) ?: return
        val o = c.getOutputStream()
        fun hdr(code: String, len: Long) = o.write("HTTP/1.1 $code\r\nContent-Length: $len\r\nConnection: close\r\n\r\n".toByteArray())
        val q = p.substringAfter('?', "").split('&').associate { it.substringBefore('=') to it.substringAfter('=', "") }
        if (q["t"] != tok) { hdr("403 Forbidden", 0); return }
        if (p.startsWith("/bye")) { cancelled = true; paused = false; hdr("200 OK", 0); o.flush(); emit(JSONObject().put("t", "cancelled").put("by", "peer")); closeAll(c); return }
        if (cancelled && !p.startsWith("/hello")) { hdr("410 Gone", 0); return }
        if (p.startsWith("/hello")) {   // receiver side: the sender scanned our QR and tells us where its files are
            hdr("200 OK", 0); o.flush()
            val sp = q["port"]?.toIntOrNull(); val st = q["st"]
            if (sp != null && st != null) { cancelled = false; paused = false; emit(JSONObject().put("t", "linked")); download(c.inetAddress.hostAddress ?: "", sp, st) }
            return
        }
        if (p.startsWith("/list")) {
            val a = JSONArray(); items.forEach { a.put(JSONObject().put("n", it.name).put("s", it.size)) }
            val b = a.toString().toByteArray(); sent.set(0); t0 = 0; fin.set(false)
            hdr("200 OK", b.size.toLong()); o.write(b)
        } else if (p.startsWith("/f/")) {
            val idx = p.substring(3).substringBefore("?").toInt()
            val item = items.getOrNull(idx) ?: return
            val off = q["o"]?.toLongOrNull() ?: 0L
            val len = q["n"]?.toLongOrNull() ?: (item.size - off)
            val total = items.sumOf { x -> x.size }
            hdr("200 OK", len)
            (if (item.path != null) FileInputStream(item.path) else contentResolver.openInputStream(item.uri!!)!!).use { ins ->
                var skipped = 0L
                while (skipped < off) { val sk = ins.skip(off - skipped); if (sk <= 0) break; skipped += sk }
                val buf = ByteArray(BUF)
                var rem = len
                while (rem > 0) {
                    while (paused && !cancelled) Thread.sleep(150); if (cancelled) break
                    val k = ins.read(buf, 0, minOf(rem, BUF.toLong()).toInt()); if (k < 0) break
                    o.write(buf, 0, k); rem -= k
                    val d = sent.addAndGet(k.toLong()); if (t0 == 0L) t0 = System.currentTimeMillis()
                    prog("s", item.name, idx + 1, items.size, d, total, t0)
                }
            }
            o.flush()
            if (sent.get() >= total && fin.compareAndSet(false, true)) emit(JSONObject().put("t", "sdone").put("size", total)
                .put("names", JSONArray().also { a -> items.forEach { x -> a.put(x.name) } }))
        }
        o.flush()
    }

    // ---------- receiver: streams straight into MediaStore (Gallery) ----------
    private fun entry(name: String, mime: String): Uri {
        val (col, dir) = when {
            mime.startsWith("image/") -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_PICTURES
            mime.startsWith("video/") -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MOVIES
            mime.startsWith("audio/") -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MUSIC
            else -> MediaStore.Downloads.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_DOWNLOADS
        }
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name); put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "$dir/FileTransfer"); put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        return contentResolver.insert(col, v)!!
    }
    // raw socket: 2 MB receive window, no HTTP library overhead
    private fun open(host: String, port: Int, path: String): Socket {
        if (cancelled) throw Cancelled()
        socks.removeAll { it.isClosed }
        val s = Socket(); s.receiveBufferSize = 2 shl 20; s.tcpNoDelay = true; s.keepAlive = true; s.soTimeout = 20000
        socks.add(s)
        try {
            s.connect(InetSocketAddress(host, port), 6000)
            s.getOutputStream().write("GET $path HTTP/1.1\r\nHost: $host\r\nConnection: close\r\n\r\n".toByteArray())
            val i = s.getInputStream(); var m = 0; val hb = StringBuilder()
            while (m < 4) {
                val b = i.read(); if (b < 0) throw java.io.IOException("closed")
                if (hb.length < 40) hb.append(b.toChar())
                val exp = if (m % 2 == 0) 13 else 10
                m = if (b == exp) m + 1 else if (b == 13) 1 else 0
            }
            val code = hb.toString().substringAfter(' ').take(3)
            if (code == "410") throw Cancelled()
            if (code != "200") throw java.io.IOException("HTTP $code")
        } catch (e: Exception) { socks.remove(s); try { s.close() } catch (x: Exception) {}; throw e }
        return s
    }
    // sender side: scanned the receiver's QR, so introduce our file server to it
    private fun link(host: String, port: Int, rt: String) = thread {
        try {
            val sp = srv?.localPort ?: throw java.io.IOException("sender not ready")
            cancelled = false; paused = false; peerHost = host; peerPort = port; peerTok = rt
            var tries = 0
            while (true) {
                try { val sk = open(host, port, "/hello?t=$rt&port=$sp&st=$tok"); sk.getInputStream().readBytes(); sk.close(); break }
                catch (e: Exception) { if (++tries >= 6) throw e; Thread.sleep(1000) }
            }
            emit(JSONObject().put("t", "linked"))
        } catch (e: Exception) {
            err("Could not reach the receiver: " + e.javaClass.simpleName + " " + (e.message ?: "") + ". Both phones must be on the same Wi-Fi or hotspot.")
        }
    }
    private fun download(host: String, port: Int, t: String) = thread {
        cancelled = false; paused = false; peerHost = host; peerPort = port; peerTok = t
        var pending: Uri? = null
        try {
            wifi(true)
            val ls = open(host, port, "/list?t=$t")
            val list = JSONArray(String(ls.getInputStream().readBytes())); ls.close()
            val n = list.length(); var total = 0L
            for (i in 0 until n) total += list.getJSONObject(i).getLong("s")
            val done = AtomicLong(0); val start = System.currentTimeMillis(); val names = JSONArray(); val uris = JSONArray()
            for (i in 0 until n) {
                val name = list.getJSONObject(i).getString("n"); val size = list.getJSONObject(i).getLong("s"); names.put(name)
                val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "application/octet-stream"
                val u = entry(name, mime); pending = u; uris.put(u.toString())
                val base = done.get()
                try {
                    contentResolver.openFileDescriptor(u, "w")!!.use { pfd ->
                        val ch = FileOutputStream(pfd.fileDescriptor).channel
                        val parts = if (size > (8L shl 20)) 4 else 1
                        val chunk = (size + parts - 1) / parts
                        val got = LongArray(parts)   // bytes already written per part: survives dropped connections
                        val fail = java.util.concurrent.atomic.AtomicReference<Exception?>(null)
                        val ws = (0 until parts).map { pi ->
                            thread {
                                try {
                                    val off = pi * chunk; val len = minOf(chunk, size - off)
                                    var fails = 0
                                    while (got[pi] < len && fail.get() == null) {
                                        try {
                                            open(host, port, "/f/$i?o=${off + got[pi]}&n=${len - got[pi]}&t=$t").use { sk ->
                                                val din = DataInputStream(sk.getInputStream())
                                                val buf = ByteArray(512 shl 10)
                                                while (got[pi] < len && fail.get() == null) {
                                                    while (paused && !cancelled) Thread.sleep(150)
                                                    if (cancelled) throw Cancelled()
                                                    val k = minOf(len - got[pi], buf.size.toLong()).toInt()
                                                    din.readFully(buf, 0, k)
                                                    ch.write(ByteBuffer.wrap(buf, 0, k), off + got[pi]); got[pi] = got[pi] + k.toLong(); fails = 0
                                                    prog("p", name, i + 1, n, done.addAndGet(k.toLong()), total, start)
                                                }
                                            }
                                        } catch (e: Cancelled) { throw e }
                                        catch (e: Exception) {
                                            if (cancelled || ++fails > 40) throw e
                                            Thread.sleep(1500)   // link dropped: wait, then continue from got[pi], not from zero
                                        }
                                    }
                                } catch (e: Exception) { fail.set(e) }
                            }
                        }
                        ws.forEach { it.join() }
                        fail.get()?.let { throw it }
                    }
                } catch (e: Exception) {
                    if (cancelled || e is Cancelled) throw e
                    done.set(base)
                    contentResolver.openOutputStream(u)!!.use { out ->
                        open(host, port, "/f/$i?t=$t").use { sk ->
                            val din = DataInputStream(sk.getInputStream())
                            val buf = ByteArray(512 shl 10); var rem = size
                            while (rem > 0) {
                                while (paused && !cancelled) Thread.sleep(150)
                                if (cancelled) throw Cancelled()
                                val k = minOf(rem, buf.size.toLong()).toInt()
                                din.readFully(buf, 0, k); out.write(buf, 0, k); rem -= k
                                prog("p", name, i + 1, n, done.addAndGet(k.toLong()), total, start)
                            }
                        }
                    }
                }
                contentResolver.update(u, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
                pending = null
            }
            val secs = maxOf(0.1, (System.currentTimeMillis() - start) / 1000.0)
            emit(JSONObject().put("t", "pdone").put("size", total).put("names", names).put("uris", uris).put("avg", total / 1048576.0 / secs))
        } catch (e: Exception) {
            pending?.let { contentResolver.delete(it, null, null) }   // cancelled or failed: remove the incomplete file
            if (e is Cancelled || cancelled) emit(JSONObject().put("t", "cancelled").put("by", if (cancelled) "me" else "peer"))
            else err("Transfer failed: " + e.javaClass.simpleName + " " + (e.message ?: "") + ". Both phones must be on the same Wi-Fi or hotspot.")
        } finally { wifi(false) }
    }

    // ---------- Fast mode: direct Wi-Fi link between the phones (no router needed) ----------
    private var hotspot: WifiManager.LocalOnlyHotspotReservation? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { startHotspot() }
    private fun fastPerms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.NEARBY_WIFI_DEVICES)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    private fun ensureServer() {
        if (srv == null) {
            tok = java.lang.Long.toHexString(java.util.Random().nextLong() and 0xffffffffL)
            srv = ServerSocket(0, 50); serve(); wifi(true); svc(true)
        }
    }
    private fun hotIp(): String {
        for (n in NetworkInterface.getNetworkInterfaces()) for (a in n.inetAddresses)
            if (a is Inet4Address && !a.isLoopbackAddress && a.isSiteLocalAddress && a.address[3] == 1.toByte()) return a.hostAddress ?: ""
        return ""
    }
    private fun stopHotspot() { try { hotspot?.close() } catch (e: Exception) {}; hotspot = null }
    private fun unbind() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            netCb?.let { cm.unregisterNetworkCallback(it) }; netCb = null
            cm.bindProcessToNetwork(null)
        } catch (e: Exception) {}
        try {   // leave the receiver's temporary Wi-Fi and go back to the normal one
            if (legacyId >= 0) {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION") wm.removeNetwork(legacyId); legacyId = -1; wm.reconnect()
            }
        } catch (e: Exception) {}
    }
    private fun startHotspot() {
        stopHotspot()
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(reservation: WifiManager.LocalOnlyHotspotReservation?) {
                    val r = reservation ?: return
                    hotspot = r
                    var ssid = ""; var pass = ""
                    if (Build.VERSION.SDK_INT >= 30) { val c = r.softApConfiguration; ssid = c.ssid ?: ""; pass = c.passphrase ?: "" }
                    else { @Suppress("DEPRECATION") val c = r.wifiConfiguration; ssid = c?.SSID ?: ""; pass = c?.preSharedKey ?: "" }
                    ssid = ssid.trim('"'); pass = pass.trim('"')
                    thread {
                        var h = ""
                        repeat(10) { if (h.isEmpty()) { h = hotIp(); if (h.isEmpty()) Thread.sleep(400) } }
                        if (h.isEmpty()) h = ip()
                        ensureServer()
                        val sec = if (Build.VERSION.SDK_INT >= 30) r.softApConfiguration.securityType else 1
                        fun b64(x: String) = android.util.Base64.encodeToString(x.toByteArray(), android.util.Base64.NO_WRAP or android.util.Base64.URL_SAFE)
                        emit(JSONObject().put("t", "qr").put("qr", "FT4|$h|${srv!!.localPort}|$tok|${b64(ssid)}|${b64(pass)}|$sec|${ip().let { if (it == h) "" else it }}"))
                    }
                }
                override fun onFailed(reason: Int) { err("Fast mode could not start (code $reason). Turn on Location, turn off any hotspot, then try again.") }
                override fun onStopped() {}
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) { err("Fast mode failed: " + e.javaClass.simpleName + " " + (e.message ?: "")) }
    }
    // sender side: join the receiver's direct Wi-Fi, then introduce ourselves
    private fun specJoin(ip0: String, port: Int, rt: String, ssid: String, pass: String, sec: Int = 1, ipN: String = "") {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val sb = WifiNetworkSpecifier.Builder().setSsid(ssid)
            if (sec == 3) sb.setWpa3Passphrase(pass) else sb.setWpa2Passphrase(pass)
            val spec = sb.build()
            val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).setNetworkSpecifier(spec).build()
            netCb?.let { try { cm.unregisterNetworkCallback(it) } catch (e: Exception) {} }
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    cm.bindProcessToNetwork(network)
                    val gw = cm.getLinkProperties(network)?.routes
                        ?.firstOrNull { it.hasGateway() && it.gateway is Inet4Address }?.gateway?.hostAddress ?: ip0
                    link(gw, port, rt)
                }
                override fun onUnavailable() { if (ipN.isNotEmpty()) { status("Trying the normal Wi-Fi route..."); link(ipN, port, rt); return }; err("Could not join the receiver's direct Wi-Fi. Tap Connect when Android asks. If it keeps failing, ask the receiver to switch Fast mode off and scan the new QR.") }
            }
            netCb = cb
            cm.requestNetwork(req, cb, 30000)
        } catch (e: Exception) { err("Fast mode failed: " + e.javaClass.simpleName + " " + (e.message ?: "")) }
    }

    private fun icon(d: android.graphics.drawable.Drawable): String {
        val sz = 64
        val bm = android.graphics.Bitmap.createBitmap(sz, sz, android.graphics.Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, sz, sz); d.draw(android.graphics.Canvas(bm))
        val bo = java.io.ByteArrayOutputStream(); bm.compress(android.graphics.Bitmap.CompressFormat.PNG, 90, bo)
        return android.util.Base64.encodeToString(bo.toByteArray(), android.util.Base64.NO_WRAP)
    }

    // split apps: pack base + all split APKs into ONE .apks file so nothing is missing
    private fun bundle(ai: android.content.pm.ApplicationInfo, label: String): File {
        val out = File(cacheDir, "$label.apks")
        ZipOutputStream(BufferedOutputStream(FileOutputStream(out), 1 shl 20)).use { z ->
            z.setLevel(0)
            (listOf(ai.sourceDir) + (ai.splitSourceDirs ?: emptyArray<String>())).forEach { p ->
                val f = File(p); z.putNextEntry(ZipEntry(f.name))
                f.inputStream().use { it.copyTo(z, 1 shl 20) }; z.closeEntry()
            }
        }
        return out
    }

    // ---------- Sender: join the receiver's direct Wi-Fi quickly (ShareMe-style), with step-by-step status ----------
    private var legacyId = -1
    private fun status(m: String) = emit(JSONObject().put("t", "status").put("msg", m))
    @Suppress("DEPRECATION")
    private fun bindToSubnet(ip0: String) {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val pre = ip0.substringBeforeLast('.')
            for (n in cm.allNetworks) {
                val lp = cm.getLinkProperties(n) ?: continue
                if (lp.linkAddresses.any { (it.address.hostAddress ?: "").startsWith("$pre.") }) { cm.bindProcessToNetwork(n); return }
            }
        } catch (e: Exception) {}
    }
    // Silent join with the classic Wi-Fi API (works because the app targets an older Android level). No pop-up, usually under 2 seconds.
    @Suppress("DEPRECATION")
    private fun legacyJoin(ssid: String, pass: String, ip0: String): Boolean {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (!wm.isWifiEnabled) wm.isWifiEnabled = true
            val q = "\"" + ssid + "\""
            val conf = android.net.wifi.WifiConfiguration()
            conf.SSID = q; conf.preSharedKey = "\"" + pass + "\""
            conf.allowedKeyManagement.set(android.net.wifi.WifiConfiguration.KeyMgmt.WPA_PSK)
            wm.configuredNetworks?.filter { it.SSID == q }?.forEach { wm.removeNetwork(it.networkId) }
            val id = wm.addNetwork(conf)
            if (id < 0) return false
            legacyId = id
            wm.disconnect(); wm.enableNetwork(id, true); wm.reconnect()
            val end = System.currentTimeMillis() + 15000
            while (System.currentTimeMillis() < end) {
                val g = wm.dhcpInfo.gateway
                if (g != 0 && "${g and 255}.${(g shr 8) and 255}.${(g shr 16) and 255}.${(g shr 24) and 255}" == ip0) { bindToSubnet(ip0); return true }
                Thread.sleep(250)
            }
        } catch (e: Exception) {}
        return false
    }
    private fun joinAndLink(ip0: String, port: Int, rt: String, ssid: String, pass: String, sec: Int = 1, ipN: String = "") {
        thread {
            status("Connecting to the receiver...")
            if (ip0.isNotEmpty() && legacyJoin(ssid, pass, ip0)) {
                status("Joined the direct Wi-Fi")
                link(ip0, port, rt)
            } else {
                status("Asking Android to join the direct Wi-Fi... tap Connect if it asks")
                specJoin(ip0, port, rt, ssid, pass, sec, ipN)
            }
        }
    }

    inner class Bridge {
        @JavascriptInterface fun pick() { runOnUiThread { picker.launch(arrayOf("*/*")) } }
        @JavascriptInterface fun clear() { items.clear(); emitFiles() }
        @JavascriptInterface fun start(): String {
            ensureServer()
            return JSONObject().put("ip", ip()).put("port", srv!!.localPort).put("tok", tok).toString()
        }
        @JavascriptInterface fun fast(on: Boolean) { runOnUiThread { if (on) permLauncher.launch(fastPerms()) else stopHotspot() } }
        @JavascriptInterface fun apps() {
            thread {
                val pm = packageManager
                val ri = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                val seen = HashSet<String>(); val tmp = ArrayList<JSONObject>()
                for (r in ri) {
                    val ai = r.activityInfo.applicationInfo
                    if (!seen.add(ai.packageName)) continue
                    val sp = ai.splitSourceDirs
                    var size = File(ai.sourceDir).length(); sp?.forEach { size += File(it).length() }
                    tmp.add(JSONObject().put("p", ai.packageName).put("n", r.loadLabel(pm).toString())
                        .put("s", size).put("sp", sp?.size ?: 0).put("i", icon(r.loadIcon(pm))))
                }
                tmp.sortBy { it.getString("n").lowercase() }
                emit(JSONObject().put("t", "apps").put("list", JSONArray(tmp)))
            }
        }
        @JavascriptInterface fun addApps(json: String) {
            thread {
                val pm = packageManager; val arr = JSONArray(json)
                for (i in 0 until arr.length()) {
                    try {
                        val ai = pm.getApplicationInfo(arr.getString(i), 0)
                        val label = pm.getApplicationLabel(ai).toString().replace(Regex("[^A-Za-z0-9 _.-]"), "").trim().ifEmpty { ai.packageName }
                        if (ai.splitSourceDirs.isNullOrEmpty()) { val b = File(ai.sourceDir); items.add(Item(null, "$label.apk", b.length(), b.path)) }
                        else { val b = bundle(ai, label); items.add(Item(null, "$label.apks", b.length(), b.path)) }
                    } catch (e: Exception) { err("Could not add app: " + e.javaClass.simpleName + " " + (e.message ?: "")) }
                }
                emitFiles()
            }
        }
        @JavascriptInterface fun install(uri: String) {
            runOnUiThread {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(uri), "application/vnd.android.package-archive")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) { err("Open the file from Downloads > FileTransfer to install it.") }
            }
        }
        @JavascriptInterface fun pause(on: Boolean) { paused = on }
        @JavascriptInterface fun snapshot(): String = snap
        @JavascriptInterface fun minimize() { runOnUiThread { moveTaskToBack(true) } }
        @JavascriptInterface fun cancel() {
            cancelled = true; paused = false
            val h = peerHost; val pt = peerPort; val tk = peerTok
            thread {
                try { if (h.isNotEmpty()) Socket().use { sk -> sk.connect(InetSocketAddress(h, pt), 3000); sk.getOutputStream().write("GET /bye?t=$tk HTTP/1.1\r\nHost: $h\r\nConnection: close\r\n\r\n".toByteArray()); sk.getOutputStream().flush(); sk.getInputStream().read() } } catch (e: Exception) {}
                closeAll()
                emit(JSONObject().put("t", "cancelled").put("by", "me"))
            }
        }
        @JavascriptInterface fun scan() {
            runOnUiThread {
                scanner.launch(ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                    .setPrompt("Scan the QR code shown on the other phone").setBeepEnabled(false).setOrientationLocked(false))
            }
        }
        @JavascriptInterface fun stop() {
            try { srv?.close() } catch (e: Exception) {}
            srv = null; items.clear(); wifi(false); stopHotspot(); unbind(); svc(false); cancelled = false; paused = false; snap = ""; cacheDir.listFiles()?.filter { it.name.endsWith(".apks") }?.forEach { it.delete() }
        }
    }
}
