package com.saad.filetransfer

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataInputStream
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread

data class Item(val uri: Uri, val name: String, val size: Long)

class MainActivity : ComponentActivity() {
    private lateinit var wv: WebView
    private val items = java.util.concurrent.CopyOnWriteArrayList<Item>()
    private var srv: ServerSocket? = null
    private var tok = ""
    private val sent = AtomicLong(0)
    @Volatile private var t0 = 0L
    @Volatile private var last = 0L
    private var lock: WifiManager.WifiLock? = null
    private val BUF = 1 shl 20
    private val fin = AtomicBoolean(false)

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { us ->
        us.forEach { u ->
            contentResolver.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) items.add(Item(u,
                    c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)),
                    c.getLong(c.getColumnIndexOrThrow(OpenableColumns.SIZE))))
            }
        }
        emitFiles()
    }

    private val scanner = registerForActivityResult(ScanContract()) { r ->
        val txt = r.contents
        if (txt != null) {
            val p = txt.split("|")
            if (p.size == 4 && p[0] == "FT1") download(p[1], p[2].toIntOrNull() ?: 0, p[3])
            else err("That is not a File Transfer QR code.")
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        wv = WebView(this)
        setContentView(wv)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.loadUrl("file:///android_asset/index.html")
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { wv.evaluateJavascript("goBack()") { if (it != "true") finish() } }
        })
    }

    private fun emit(o: JSONObject) { wv.post { wv.evaluateJavascript("onNative($o)", null) } }
    private fun err(m: String) = emit(JSONObject().put("t", "err").put("msg", m))
    private fun emitFiles() {
        val a = JSONArray(); items.forEach { a.put(JSONObject().put("n", it.name).put("s", it.size)) }
        emit(JSONObject().put("t", "files").put("list", a))
    }
    private fun wifi(on: Boolean) {
        if (on) {
            if (lock == null) lock = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
                .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "ft").apply { setReferenceCounted(false) }
            lock?.acquire()
        } else if (lock?.isHeld == true) lock?.release()
    }
    private fun prog(t: String, name: String, i: Int, n: Int, done: Long, total: Long, start: Long) {
        val now = System.currentTimeMillis()
        if (now - last < 200 && done < total) return
        last = now
        val sp = done / 1048576.0 / maxOf(0.1, (now - start) / 1000.0)
        emit(JSONObject().put("t", t).put("name", name).put("i", i).put("n", n).put("done", done)
            .put("total", total).put("speed", sp).put("eta", if (sp > 0) (total - done) / 1048576.0 / sp else 0.0))
    }
    private fun ip(): String {
        var best = ""
        for (n in NetworkInterface.getNetworkInterfaces()) for (a in n.inetAddresses)
            if (a is Inet4Address && !a.isLoopbackAddress && a.isSiteLocalAddress &&
                (best.isEmpty() || n.name.startsWith("wlan") || n.name.startsWith("ap"))) best = a.hostAddress ?: ""
        return best
    }

    // ---------- sender: raw-TCP HTTP server, 1 MB buffers ----------
    private fun serve() = thread(isDaemon = true) {
        val s = srv ?: return@thread
        while (!s.isClosed) {
            val c = try { s.accept() } catch (e: Exception) { break }
            thread { try { handle(c) } catch (e: Exception) {} finally { try { c.close() } catch (e: Exception) {} } }
        }
    }
    private fun handle(c: Socket) {
        c.sendBufferSize = 2 shl 20; c.tcpNoDelay = true
        val r = c.getInputStream().bufferedReader()
        val line = r.readLine() ?: return
        while (!r.readLine().isNullOrEmpty()) { }
        val p = line.split(" ").getOrNull(1) ?: return
        val o = c.getOutputStream()
        fun hdr(code: String, len: Long) = o.write("HTTP/1.1 $code\r\nContent-Length: $len\r\nConnection: close\r\n\r\n".toByteArray())
        val q = p.substringAfter('?', "").split('&').associate { it.substringBefore('=') to it.substringAfter('=', "") }
        if (q["t"] != tok) { hdr("403 Forbidden", 0); return }
        if (p.startsWith("/list")) {
            val a = JSONArray(); items.forEach { a.put(JSONObject().put("n", it.name).put("s", it.size)) }
            val b = a.toString().toByteArray(); sent.set(0); t0 = 0; fin.set(false)
            hdr("200 OK", b.size.toLong()); o.write(b)
        } else if (p.startsWith("/f/")) {
            val idx = p.substring(3).substringBefore("?").toInt()
            val item = items.getOrNull(idx) ?: return
            val off = q["o"]?.toLongOrNull() ?: 0L
            val len = q["n"]?.toLongOrNull() ?: (item.size - off)
            val total = items.sumOf { x -> x.size }
            hdr("200 OK", len)
            contentResolver.openFileDescriptor(item.uri, "r")!!.use { pfd ->
                val ch = FileInputStream(pfd.fileDescriptor).channel
                ch.position(off)
                val bb = ByteBuffer.allocate(BUF)
                var rem = len
                while (rem > 0) {
                    bb.clear(); bb.limit(minOf(rem, BUF.toLong()).toInt())
                    val k = ch.read(bb); if (k < 0) break
                    o.write(bb.array(), 0, k); rem -= k
                    val d = sent.addAndGet(k.toLong()); if (t0 == 0L) t0 = System.currentTimeMillis()
                    prog("s", item.name, idx + 1, items.size, d, total, t0)
                }
            }
            o.flush()
            if (sent.get() >= total && fin.compareAndSet(false, true)) emit(JSONObject().put("t", "sdone").put("size", total)
                .put("names", JSONArray().also { a -> items.forEach { x -> a.put(x.name) } }))
        }
        o.flush()
    }

    // ---------- receiver: streams straight into MediaStore (Gallery) ----------
    private fun entry(name: String, mime: String): Uri {
        val (col, dir) = when {
            mime.startsWith("image/") -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_PICTURES
            mime.startsWith("video/") -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MOVIES
            mime.startsWith("audio/") -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MUSIC
            else -> MediaStore.Downloads.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_DOWNLOADS
        }
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name); put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "$dir/FileTransfer"); put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        return contentResolver.insert(col, v)!!
    }
    // raw socket: 2 MB receive window, no HTTP library overhead
    private fun open(host: String, port: Int, path: String): Socket {
        val s = Socket(); s.receiveBufferSize = 2 shl 20; s.tcpNoDelay = true; s.soTimeout = 20000
        s.connect(InetSocketAddress(host, port), 6000)
        s.getOutputStream().write("GET $path HTTP/1.1\r\nHost: $host\r\nConnection: close\r\n\r\n".toByteArray())
        val i = s.getInputStream(); var m = 0
        while (m < 4) {
            val b = i.read(); if (b < 0) throw java.io.IOException("closed")
            val exp = if (m % 2 == 0) 13 else 10
            m = if (b == exp) m + 1 else if (b == 13) 1 else 0
        }
        return s
    }
    private fun download(host: String, port: Int, t: String) = thread {
        var pending: Uri? = null
        try {
            wifi(true)
            val ls = open(host, port, "/list?t=$t")
            val list = JSONArray(String(ls.getInputStream().readBytes())); ls.close()
            val n = list.length(); var total = 0L
            for (i in 0 until n) total += list.getJSONObject(i).getLong("s")
            val done = AtomicLong(0); val start = System.currentTimeMillis(); val names = JSONArray()
            for (i in 0 until n) {
                val name = list.getJSONObject(i).getString("n"); val size = list.getJSONObject(i).getLong("s"); names.put(name)
                val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "application/octet-stream"
                val u = entry(name, mime); pending = u
                contentResolver.openFileDescriptor(u, "rw")!!.use { pfd ->
                    val ch = FileOutputStream(pfd.fileDescriptor).channel
                    val parts = if (size > (8L shl 20)) 4 else 1
                    val chunk = (size + parts - 1) / parts
                    val fail = java.util.concurrent.atomic.AtomicReference<Exception?>(null)
                    val ws = (0 until parts).map { pi ->
                        thread {
                            try {
                                val off = pi * chunk; val len = minOf(chunk, size - off)
                                if (len > 0) open(host, port, "/f/$i?o=$off&n=$len&t=$t").use { sk ->
                                    val din = DataInputStream(sk.getInputStream())
                                    val buf = ByteArray(512 shl 10); var pos = off; var rem = len
                                    while (rem > 0 && fail.get() == null) {
                                        val k = minOf(rem, buf.size.toLong()).toInt()
                                        din.readFully(buf, 0, k)
                                        ch.write(ByteBuffer.wrap(buf, 0, k), pos); pos += k; rem -= k
                                        prog("p", name, i + 1, n, done.addAndGet(k.toLong()), total, start)
                                    }
                                }
                            } catch (e: Exception) { fail.set(e) }
                        }
                    }
                    ws.forEach { it.join() }
                    fail.get()?.let { throw it }
                }
                contentResolver.update(u, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
                pending = null
            }
            val secs = maxOf(0.1, (System.currentTimeMillis() - start) / 1000.0)
            emit(JSONObject().put("t", "pdone").put("size", total).put("names", names).put("avg", total / 1048576.0 / secs))
        } catch (e: Exception) {
            pending?.let { contentResolver.delete(it, null, null) }
            err("Transfer failed. Make sure both phones are on the same Wi-Fi or hotspot, then try again.")
        } finally { wifi(false) }
    }

    inner class Bridge {
        @JavascriptInterface fun pick() { runOnUiThread { picker.launch(arrayOf("*/*")) } }
        @JavascriptInterface fun clear() { items.clear(); emitFiles() }
        @JavascriptInterface fun start(): String {
            val ip = ip(); if (ip.isEmpty()) return "{}"
            if (srv == null) {
                tok = java.lang.Long.toHexString(java.util.Random().nextLong() and 0xffffffffL)
                srv = ServerSocket(0, 50); serve(); wifi(true)
            }
            return JSONObject().put("ip", ip).put("port", srv!!.localPort).put("tok", tok).toString()
        }
        @JavascriptInterface fun scan() {
            runOnUiThread {
                scanner.launch(ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                    .setPrompt("Scan the QR code on the sender's phone").setBeepEnabled(false).setOrientationLocked(false))
            }
        }
        @JavascriptInterface fun stop() {
            try { srv?.close() } catch (e: Exception) {}
            srv = null; items.clear(); wifi(false)
        }
    }
}
