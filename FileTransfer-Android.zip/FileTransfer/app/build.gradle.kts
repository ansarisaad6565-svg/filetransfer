plugins{id("com.android.application");id("org.jetbrains.kotlin.android")}
android{
 namespace="com.saad.filetransfer";compileSdk=34
 buildFeatures { buildConfig = true }
 defaultConfig{applicationId="com.saad.filetransfer";minSdk=29;targetSdk=34;versionCode=55;versionName="6.13"}
 buildTypes{release{isMinifyEnabled=false}}
 compileOptions{sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17}
 kotlinOptions{jvmTarget="17"}
 signingConfigs{getByName("debug"){storeFile=file("ft.jks");storePassword="filetransfer";keyAlias="ft";keyPassword="filetransfer"}}
}
dependencies{
 implementation("androidx.activity:activity-ktx:1.9.0")
 implementation("androidx.camera:camera-camera2:1.3.4")
 implementation("androidx.camera:camera-lifecycle:1.3.4")
 implementation("androidx.camera:camera-view:1.3.4")
 implementation("com.google.mlkit:barcode-scanning:17.3.0")
}
