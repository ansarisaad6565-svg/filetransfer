FILE TRANSFER — FAST MODE CONNECTION FIX (v2.9)
Created by Saad

WHAT CHANGED
- Fast Mode now handles open, WPA2, WPA2/WPA3 transition, and WPA3 local-only hotspots correctly.
- Improved hotspot IP detection across different Android phone manufacturers.
- Improved receiver-address/gateway retry logic and process network binding.
- Added permission and invalid-QR checks with clearer error messages.
- Version code increased to 11 so this build can update v2.8 without uninstalling it, when signed with the same key.

BUILD
1. Install Android Studio: https://developer.android.com/studio
2. Extract this ZIP and open the FileTransfer folder in Android Studio.
3. Let Gradle sync complete (internet is needed for dependencies).
4. Select Build > Build Bundle(s)/APK(s) > Build APK(s).
5. Install the generated APK on all phones you want to test.

TEST FAST MODE
1. Update/install the same build on both phones.
2. On the receiving phone, tap Receive and enable Fast Mode. Keep this screen open.
3. On the sending phone, choose files, tap Next, and scan the receiver QR once.
4. Accept Android's Wi-Fi connection prompt if shown. Allow the requested Nearby Wi-Fi/Location permissions.
5. If Android still refuses the connection, restart Fast Mode on both phones and scan the fresh QR. Some OEM Android builds restrict LocalOnlyHotspot/WifiNetworkSpecifier behavior; this project has not been device-tested in this environment, so successful connection cannot be guaranteed until tested on your phones.

NOTE
This ZIP contains Android source code, not a prebuilt APK. Android Studio/Gradle must build it. Keep the included signing key private if you intend to distribute updates under the same app identity.
